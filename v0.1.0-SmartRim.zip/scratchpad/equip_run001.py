import json, sys
sys.path.insert(0, r"C:\Users\fred\Desktop\RimWorld Consellor\RimAutonomous\sidecar")
from counselor import _call

MATTHEW = "Matthew Po"
CAMI = "Camilla 'Cami' Maney"
ANDY = "Andrew 'Andy' Camden"

# Matthew: rifle (shooting 8) + flak helmet
print("Matthew rifle:", _call("manage_gear", {"name": MATTHEW, "op": "equip", "item": "Gun_BoltActionRifle3753"}).get("ok"))
print("Matthew helmet:", _call("manage_gear", {"name": MATTHEW, "op": "wear", "item": "Apparel_AdvancedHelmet3758"}).get("ok"))
# Camilla: knife (melee 9) + flak vest (she is the medic)
print("Cami knife:", _call("manage_gear", {"name": CAMI, "op": "equip", "item": "MeleeWeapon_Knife3755"}).get("ok"))
print("Cami vest:", _call("manage_gear", {"name": CAMI, "op": "wear", "item": "Apparel_FlakVest3757"}).get("ok"))
# Andy: revolver (shooting 6) + flak pants
print("Andy revolver:", _call("manage_gear", {"name": ANDY, "op": "equip", "item": "Gun_Revolver3754"}).get("ok"))
print("Andy pants:", _call("manage_gear", {"name": ANDY, "op": "wear", "item": "Apparel_FlakPants3756"}).get("ok"))

# Cooking bill on the stove
r = _call("inspect_thing", {"x": 143, "z": 142})
if r.get("id"):
    print("cook bill:", _call("add_bill", {"id": r["id"], "recipe": "CookMealSimple", "count": 10}).get("ok"))

# Research already set to Smithing
print("research:", _call("get_research").get("current"))

# Verify
st = _call("get_status")
for c in st["bundled"]["list_colonists"]["colonists"]:
    g = _call("get_pawn", {"id": c["id"]})
    print(c["name"], "weapon=", g.get("weapon"))
