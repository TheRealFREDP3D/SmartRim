import json, requests
URL="http://localhost:8787/"
def call(n,a=None):
    p={'jsonrpc':'2.0','id':1,'method':'tools/call','params':{'name':n,'arguments':a or {}}}
    r=requests.post(URL,json=p,timeout=30)
    d=r.json(); t=d['result']['content'][0]['text']
    try: return json.loads(t)
    except: return {'text':t}

st=call('get_status')
henry=[c['id'] for c in st['bundled']['list_colonists']['colonists'] if c['name']=="Henry 'Lawman' Jensen"][0]
print('draft:', call('draft',{'action':'draft','ids':henry}))
enemy='Human53148'
opts=call('order_pawn',{'id':henry,'targetId':enemy})
print('options:', opts)
# find an attack option
for o in (opts.get('options') or opts.get('commands') or []):
    print('  opt:', o)
