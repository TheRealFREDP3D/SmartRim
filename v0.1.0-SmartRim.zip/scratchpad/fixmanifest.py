import os, json, time
CACHE = r"C:\Users\fred\Desktop\RimWorld Consellor\RimAutonomous\memory\wiki"
BASE = "https://rimworldwiki.com/wiki/"
files = sorted(os.listdir(CACHE))
htmls = [f for f in files if f.endswith(".html")]
manifest = {}
for fn in htmls:
    slug = fn.replace(".html", "")
    path = os.path.join(CACHE, fn)
    manifest[slug] = {
        "url": BASE + slug,
        "fetched": time.strftime("%Y-%m-%d"),
        "size": os.path.getsize(path),
    }
with open(os.path.join(CACHE, "manifest.json"), "w", encoding="utf-8") as f:
    json.dump(manifest, f, indent=2)
print("manifest entries:", len(manifest))
