import json, requests
URL="http://localhost:8787/"
def call(n,a=None):
    p={'jsonrpc':'2.0','id':1,'method':'tools/call','params':{'name':n,'arguments':a or {}}}
    r=requests.post(URL,json=p,timeout=30)
    d=r.json(); t=d['result']['content'][0]['text']
    try: return json.loads(t)
    except: return {'text':t}

for op in ['wear','equip_apparel','apparel','put_on']:
    r=call('manage_gear',{'name':"Dominic 'Byte' Byter",'op':op,'item':'Apparel_FlakVest4921'})
    print(op, '->', r.get('ok'), r.get('error'))
# Try do_thing_action on the apparel item with 'Wear' label?
r=call('inspect_thing',{'id':'Apparel_FlakVest4921'})
print('actions:', [a.get('label') for a in r.get('actions',[])])
