"""Advance time in ~1.2h slices, pausing at each slice. Stops early on an event."""
import json
import sys
import time

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.path.insert(0, "sidecar")
from mcp_client import McpClient
from config import MCP_URL, MCP_DELAY

c = McpClient(MCP_URL, delay=MCP_DELAY)


def hard_pause():
    """Never leave the game running: force a pause and report."""
    try:
        r = c.call_tool("set_speed", {"action": "pause"})
        if not r.get("paused", False):
            print("WARN pause not confirmed:", json.dumps(r, ensure_ascii=False)[:300])
    except Exception as exc:  # noqa: BLE001
        print("WARN pause call failed:", exc)


def clear_stuck_wait():
    """Close leftover WaitOverlayWindow(s); the server clears its wait state a moment later."""
    cleared = False
    try:
        w = c.call_tool("list_windows", {})
        for win in w.get("windows", []):
            if win.get("type") == "WaitOverlayWindow":
                c.call_tool("window_action", {"index": win["index"], "close": True})
                cleared = True
    except Exception as exc:  # noqa: BLE001
        print("WARN clear wait failed:", exc)
    if cleared:
        time.sleep(1.0)
    return cleared


def wait_once(hours=1.2):
    """Call wait_for_event, recovering from a stale 'wait already in progress' state.

    The server's wait flag only clears after the game actually ticks, so nudge the
    clock forward for a moment instead of hammering the tool.
    """
    for attempt in range(4):
        r = c.call_tool("wait_for_event", {"maxGameHours": hours, "pause": "always"})
        if "already in progress" not in str(r.get("error", "")):
            return r
        clear_stuck_wait()
        print("stuck wait: nudging clock to clear it")
        c.call_tool("set_speed", {"action": "unpause"})
        time.sleep(1.5)
        hard_pause()
    return r


slices = int(sys.argv[1]) if len(sys.argv) > 1 else 4
for i in range(slices):
    try:
        r = wait_once()
    except Exception as exc:  # noqa: BLE001
        print(f"[{i+1}] ERROR wait raised: {exc}")
        hard_pause()
        break
    t = r.get("time", {})
    if not t:
        print(f"[{i+1}] ERROR no time in reply: {json.dumps(r, ensure_ascii=False)[:400]}")
        hard_pause()
        break
    print(f"[{i+1}] {t.get('date')} {t.get('hour')}h event={r.get('event')} cause={r.get('cause')} delta={json.dumps(r.get('_delta'))[:200]}")
    if r.get("event"):
        print("EVENT:", json.dumps(r, ensure_ascii=False)[:800])
        break

hard_pause()
