import json, requests

def call(name, args=None):
    payload = {'jsonrpc':'2.0','id':1,'method':'tools/call','params':{'name':name,'arguments':args or {}}}
    resp = requests.post('http://localhost:8787/', json=payload, timeout=5)
    return json.loads(resp.json()['result']['content'][0]['text'])

# Try variations of the work type names
variations = [
    "Firefight", "Firefighting", "Fire",
    "BedRest", "Bed Rest", "Bedrest", "bedrest",
    "Basic", "basic",
    "Haul", "Hauling",
    "Clean", "Cleaning",
]

for wt in variations:
    r = call('set_work_priority', {'name': 'Creed', 'workType': wt, 'priority': 1})
    if r.get('ok'):
        print(f"  VALID: {wt}")
    else:
        err = r.get('error', '')
        if 'Unknown' in err:
            pass
        else:
            print(f"  {wt}: {err}")
print("Done")
