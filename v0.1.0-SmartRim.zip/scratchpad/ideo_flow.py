"""Advance the fluid-ideoligion guided flow with its generated defaults, then finalize."""
import json
import sys

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.path.insert(0, "sidecar")
from mcp_client import McpClient
from config import MCP_URL, MCP_DELAY

client = McpClient(MCP_URL, delay=MCP_DELAY)

for i in range(20):
    r = client.call_tool("edit_ideoligion", {"action": "next_step"})
    step = r.get("currentStep") if isinstance(r, dict) else None
    ok = r.get("ok") if isinstance(r, dict) else None
    print(i, "ok=", ok, "step=", step, "err=", (r.get("error") or "")[:80] if isinstance(r, dict) else "")
    if not ok:
        break

r = client.call_tool("edit_ideoligion", {"action": "finalize"})
print("finalize:", json.dumps(r, ensure_ascii=False)[:300])
print("status:", json.dumps(client.call_tool("game_setup_status"), ensure_ascii=False)[:300])
