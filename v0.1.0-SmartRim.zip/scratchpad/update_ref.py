path = r"C:\Users\fred\Desktop\RimWorld Consellor\RimAutonomous\MCP-REFERENCE.md"
content = open(path, encoding="utf-8").read()
if "Project goal (reoriented)" not in content:
    content = "# RimWorld MCP Project\n\n## Project goal (reoriented)\n\nThe end goal is a system that **auto-plays RimWorld**. The human is a spectator who can intervene at any time: give orders, change parameters, pause/resume, or override decisions. The advisor-only stance from earlier phases is a stepping stone, not the destination.\n\n" + content.split("# RimWorld MCP Project\n", 1)[1]
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    print("updated")
else:
    print("already present")
