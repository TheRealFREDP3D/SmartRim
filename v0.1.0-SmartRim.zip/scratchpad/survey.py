import json, requests
URL="http://localhost:8787/"
def call(n,a=None):
    p={'jsonrpc':'2.0','id':1,'method':'tools/call','params':{'name':n,'arguments':a or {}}}
    r=requests.post(URL,json=p,timeout=30)
    d=r.json(); t=d['result']['content'][0]['text']
    try: return json.loads(t)
    except: return {'text':t}

for (x1,z1,x2,z2) in [(125,125,145,145),(130,130,150,150),(115,130,135,150),(140,120,160,140)]:
    a=call('get_area',{'minX':x1,'minZ':z1,'maxX':x2,'maxZ':z2,'summary':True})
    tg=a.get('thingGroups',[])
    trees=sum(g['count'] for g in tg if 'Tree' in g['def'])
    razor=sum(g['count'] for g in tg if 'Razor' in g['def'])
    soil=a.get('terrainSummary',{}).get('Soil',0)
    print(f'{x1}-{x2},{z1}-{z2}: trees={trees} razor={razor} soil={soil}')
