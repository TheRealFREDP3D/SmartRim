"""Append run-003 lessons L-0051 (stale MCP state) and L-0052 (stuck wait_for_event)."""
import json
import pathlib

path = pathlib.Path("memory/lessons.jsonl")
existing = [json.loads(l) for l in path.read_text(encoding="utf-8").splitlines() if l.strip()]
have = {l["id"] for l in existing}

lessons = [
    {
        "id": "L-0051",
        "title": "MCP deltas and recentMessages can carry state from a previous colony; absolute queries are live",
        "trigger": {"phases": ["stabilization", "expansion"], "threats": [], "resources": [], "difficulty": [], "storyteller": [], "biome": []},
        "recommendation": "When a delta block claims a large arrival of items, or recentMessages quote colonists who are not in this run, re-verify with inspect_thing or get_resource_readout before planning around it. Per-thing queries and the trade window read live values; the delta layer and message log can mix in state from an earlier save.",
        "rationale": "run-003: after the trade window closed, list_trade still named the previous run's trader (Rodion/Cami) and get_alerts.recentMessages quoted run-002 events (Lucia Bonilla, 'Make simple helmet'). A delta also reported +500 silver, +25 medicine and +8 meals arriving in one cell with no matching letter.",
        "source": ["run-003 session log", "in-game diagnosis 2026-10-20"],
        "confidence": 0.55,
        "tags": ["mcp_gotcha", "verification"],
        "times_applied": 0, "times_helped": 0, "times_failed": 0,
        "status": "active", "source_runs": ["run-003"], "last_updated": "2026-10-20",
    },
    {
        "id": "L-0052",
        "title": "A failed wait_for_event can leave the game unpaused; nudge the clock and pause every time",
        "trigger": {"phases": ["stabilization", "expansion", "crisis"], "threats": [], "resources": [], "difficulty": [], "storyteller": [], "biome": []},
        "recommendation": "Wrap every time-advance call so it pauses on every exit path, including errors. If wait_for_event returns 'A wait is already in progress', unpause for about 1.5 real seconds, pause again, then retry - the server only clears its wait flag once the game ticks.",
        "rationale": "run-003: after several successful waits the call started returning no time field, and the colony was found running at Fast speed with nobody watching. The stuck state persisted across fresh client processes, survived closing the leftover WaitOverlayWindow, and only cleared after the game ran for a moment. See scratchpad/advance.py wait_once()/hard_pause().",
        "source": ["run-003 session log", "in-game diagnosis 2026-10-20"],
        "confidence": 0.85,
        "tags": ["mcp_gotcha", "safety", "harness"],
        "times_applied": 0, "times_helped": 0, "times_failed": 0,
        "status": "active", "source_runs": ["run-003"], "last_updated": "2026-10-20",
    },
]

with path.open("a", encoding="utf-8", newline="\n") as f:
    for les in lessons:
        if les["id"] in have:
            print("skipped", les["id"])
            continue
        f.write(json.dumps(les, ensure_ascii=False) + "\n")
        print("appended", les["id"])
print("total lessons:", len(existing) + len([l for l in lessons if l["id"] not in have]))
