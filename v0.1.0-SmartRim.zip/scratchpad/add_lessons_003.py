"""Append run-003 lessons L-0049 and L-0050 to the lesson store."""
import json
import pathlib

path = pathlib.Path("memory/lessons.jsonl")
existing = [json.loads(l) for l in path.read_text(encoding="utf-8").splitlines() if l.strip()]
have = {l["id"] for l in existing}

lessons = [
    {
        "id": "L-0049",
        "title": "A wall cell directly in front of a door seals the room and makes its contents invisible to trade and hauling",
        "trigger": {"phases": ["stabilization", "expansion"], "threats": [], "resources": ["silver", "food"], "difficulty": [], "storyteller": [], "biome": []},
        "recommendation": "After finishing a wall run, check every door: both cells on either side of the door must be passable. A room whose only door opens into a wall keeps its stockpile, but the game treats the contents as unreachable - hauling stops and the trade window reports 0 colony silver even though hundreds are stored.",
        "rationale": "run-003, 8 Septober: the kitchen's north wall was built into the cell immediately south of the storage room's only door. The storage room held 300 silver and every stored item; the visiting trader's window showed colony silver 0 and refused a 133-silver deal. Toggling forbid flags and re-opening the trade did nothing; deconstructing the blocking wall cell restored colony silver to 300 immediately.",
        "source": ["run-003 session log", "in-game diagnosis 2026-10-20"],
        "confidence": 0.9,
        "tags": ["base_design", "doors", "reachability", "trade"],
        "times_applied": 0, "times_helped": 0, "times_failed": 0,
        "status": "active", "source_runs": ["run-003"], "last_updated": "2026-10-20",
    },
    {
        "id": "L-0050",
        "title": "list_trade can return the previous trade session until the new window initialises",
        "trigger": {"phases": ["stabilization", "expansion"], "threats": [], "resources": ["silver"], "difficulty": [], "storyteller": [], "biome": []},
        "recommendation": "Before trusting any number from list_trade, check that trader and negotiator match the pawns you just ordered to trade. If they name someone else, the call is returning a stale deal from an earlier session - wait for the dialog, then read it again.",
        "rationale": "run-003: right after ordering the trade with Ambbrinreirro, list_trade returned a deal for 'Rodion' with negotiator 'Cami' and colony counts (30 meals, 32 medicine, 979 steel) that belonged to the previous run. Only after the dialog opened did the call report the real trader and the real colony stock.",
        "source": ["run-003 session log", "in-game diagnosis 2026-10-20"],
        "confidence": 0.7,
        "tags": ["mcp_gotcha", "trade"],
        "times_applied": 0, "times_helped": 0, "times_failed": 0,
        "status": "active", "source_runs": ["run-003"], "last_updated": "2026-10-20",
    },
]

with path.open("a", encoding="utf-8", newline="\n") as f:
    for les in lessons:
        if les["id"] in have:
            continue
        f.write(json.dumps(les, ensure_ascii=False) + "\n")
        print("appended", les["id"])
print("total lessons:", len(existing) + len([l for l in lessons if l["id"] not in have]))
