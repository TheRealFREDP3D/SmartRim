import json
import re
import sys

path = sys.argv[1] if len(sys.argv) > 1 else "memory/debriefs/run-002-adv-cassandra.response.md"
text = open(path, encoding="utf-8").read()

block = re.search(r"```json\s*(.*?)```", text, re.S)
data = json.loads(block.group(1))
keys = {"title", "cause_chain", "trigger", "recommendation", "rationale",
        "source", "wiki_pages_used", "unverified_claims", "confidence"}
print("file:", path)
print("candidates:", len(data))
for i, obj in enumerate(data, 1):
    missing = sorted(keys - set(obj))
    extra = sorted(set(obj) - keys)
    trig = obj.get("trigger") or {}
    print(f"  {i}: missing={missing} extra={extra} trigger_fields={len(trig)} conf={obj.get('confidence')}")

marker = "## Section B (summary)"
if marker in text:
    body = text.split(marker)[1]
    body = body.split("## Scoring")[0]
    bullets = [l for l in body.splitlines() if l.strip().startswith("-")]
    print("section B bullets:", len(bullets))
