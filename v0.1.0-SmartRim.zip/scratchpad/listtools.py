import json, re, requests

URL = "http://localhost:8787/"


def call(n, a=None):
    p = {"jsonrpc": "2.0", "id": 1, "method": "tools/call", "params": {"name": n, "arguments": a or {}}}
    r = requests.post(URL, json=p, timeout=30)
    d = r.json()
    t = d["result"]["content"][0]["text"]
    try:
        return json.loads(t)
    except Exception:
        return {"text": t}


r = call("help")
txt = json.dumps(r)
names = sorted(set(re.findall(r'"name":\s*"([a-z_0-9]+)"', txt)))
print(len(names), "tools")
for n in names:
    print(n)
