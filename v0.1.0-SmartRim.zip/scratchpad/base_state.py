"""Dump base-area build positions for wall/door/bed/furniture defs."""
import sys

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.path.insert(0, "sidecar")
from mcp_client import McpClient
from config import MCP_URL, MCP_DELAY

c = McpClient(MCP_URL, delay=MCP_DELAY)

BOX = (150, 124, 168, 135)
DEFS = ["Wall", "Frame_Wall", "Blueprint_Wall", "Door", "Frame_Door", "Blueprint_Door",
        "Bed", "Frame_Bed", "Blueprint_Bed", "TorchLamp", "Frame_TorchLamp", "Blueprint_TorchLamp",
        "Table1x2c", "Frame_Table1x2c", "Blueprint_Table1x2c"]


def in_box(t):
    return BOX[0] <= t["x"] <= BOX[2] and BOX[1] <= t["z"] <= BOX[3]


for d in DEFS:
    r = c.call_tool("list_things", {"defName": d, "verbose": True})
    ts = [(t["x"], t["z"]) for t in (r.get("things") or []) if in_box(t)]
    if ts:
        print(f"{d:20s} {len(ts)} {sorted(ts)}")
