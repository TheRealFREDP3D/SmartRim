import json, sys
sys.path.insert(0, r"C:\Users\fred\Desktop\RimWorld Consellor\RimAutonomous\sidecar")
from counselor import _call

WANT = ("Gun_", "MeleeWeapon_", "Apparel_", "MedicineIndustrial", "Silver", "ComponentIndustrial")
found = {}
# Rate-limited scan of the home area only (x 130-160, z 130-160)
for z in range(130, 161):
    for x in range(130, 161):
        r = _call("inspect_thing", {"x": x, "z": z})
        iid = r.get("id") or ""
        if iid.startswith(WANT):
            found[iid] = (x, z, r.get("label"))

for k, v in sorted(found.items()):
    print(k, v)
print("total:", len(found))
