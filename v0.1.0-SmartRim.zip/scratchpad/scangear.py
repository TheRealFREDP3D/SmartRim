import json, requests
URL = "http://localhost:8787/"


def call(n, a=None):
    p = {"jsonrpc": "2.0", "id": 1, "method": "tools/call", "params": {"name": n, "arguments": a or {}}}
    r = requests.post(URL, json=p, timeout=30)
    d = r.json()
    t = d["result"]["content"][0]["text"]
    try:
        return json.loads(t)
    except Exception:
        return {"text": t}


WANT = ("Gun_", "MeleeWeapon_", "Apparel_", "MedicineIndustrial", "Silver", "ComponentIndustrial")

found = {}
for z in range(125, 160):
    for x in range(125, 160):
        r = call("inspect_thing", {"x": x, "z": z})
        lab = r.get("label") or ""
        iid = r.get("id") or ""
        if iid.startswith(WANT):
            found[iid] = (x, z, lab)

for k, v in sorted(found.items()):
    print(k, v)
print("total:", len(found))
