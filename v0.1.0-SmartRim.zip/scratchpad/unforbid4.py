import json, requests, time, sys
URL="http://localhost:8787/"
def call(n,a=None):
    p={'jsonrpc':'2.0','id':1,'method':'tools/call','params':{'name':n,'arguments':a or {}}}
    r=requests.post(URL,json=p,timeout=30)
    d=r.json(); t=d['result']['content'][0]['text']
    try: return json.loads(t)
    except: return {'text':t}

r=call('list_unmanaged_items',{'limit':500,'confirm':True})
items=r['items']
ids=[t['id'] for t in items if t.get('forbidden')]
print('forbidden to unforbid:', len(ids))
done=0
for iid in ids:
    try:
        call('do_thing_action',{'id':iid,'label':'Allow'})
        done+=1
    except Exception as e:
        print('err', iid, e)
    time.sleep(0.15)
print('done', done)
sys.stdout.flush()
