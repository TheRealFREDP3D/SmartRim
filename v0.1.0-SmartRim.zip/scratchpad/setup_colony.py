"""Day-1 colony setup: work priorities, schedules, research."""
import json
import sys

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.path.insert(0, "sidecar")
from mcp_client import McpClient
from config import MCP_URL, MCP_DELAY

c = McpClient(MCP_URL, delay=MCP_DELAY)

ids = {"urist": "Human599", "remy": "Human710", "sera": "Human702"}

prios = [
    ("urist", "Doctor", 1),
    ("urist", "Plants", 2),
    ("urist", "Construction", 3),
    ("urist", "Mining", 2),
    ("remy", "Cooking", 2),
    ("remy", "Hunting", 2),
    ("remy", "Construction", 3),
    ("sera", "Research", 1),
    ("sera", "Construction", 2),
    ("sera", "Doctor", 3),
]

for who, work, p in prios:
    r = c.call_tool("set_work_priority", {"id": ids[who], "workType": work, "priority": p})
    print(who, work, p, "->", r.get("ok"), r.get("error") or r.get("priority") or r.get("message") or "")

for who, pid in ids.items():
    for h in range(22, 24):
        c.call_tool("set_schedule", {"id": pid, "assignment": "Sleep", "hour": h})
    for h in range(0, 6):
        c.call_tool("set_schedule", {"id": pid, "assignment": "Sleep", "hour": h})
    print(who, "sleep 22-06 set")

r = c.call_tool("set_research", {"project": "Smithing"})
print("research:", json.dumps(r)[:300])
