"""Reroll one candidate slot until it fits the run's team rule.

Rule: no incapables of Violent/Caring/Firefighting, no Pyromaniac, no peg leg,
and either a grower (plants >= 5) or a doctor (medical >= 5).
"""
import json
import re
import sys

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.path.insert(0, "sidecar")
from mcp_client import McpClient
from config import MCP_URL, MCP_DELAY

INDEX = int(sys.argv[1])
TRIES = int(sys.argv[2]) if len(sys.argv) > 2 else 12
client = McpClient(MCP_URL, delay=MCP_DELAY)


def skills_of(pawn):
    out = {}
    for item in pawn.get("skills") or []:
        if isinstance(item, dict):
            out[item.get("skill")] = item.get("level")
            continue
        m = re.match(r"([a-z]+)\s+(\d+)", str(item))
        if m:
            out[m.group(1)] = int(m.group(2))
    return out


def verdict(pawn):
    incap = str(pawn.get("incapableOf") or "")
    traits = " ".join(t.get("label", "") if isinstance(t, dict) else str(t) for t in pawn.get("traits") or [])
    health = " ".join(str(h) for h in pawn.get("health") or [])
    sk = skills_of(pawn)
    problems = []
    for banned in ("Violent", "Caring", "Firefighting"):
        if banned in incap:
            problems.append("incapable " + banned)
    if "Pyromaniac" in traits:
        problems.append("pyromaniac")
    if "peg leg" in health.lower() or "Removed" in health:
        problems.append("leg damage")
    if sk.get("plants", 0) < 5 and sk.get("medical", 0) < 5:
        problems.append("no grower/doctor")
    return problems, sk


for attempt in range(1, TRIES + 1):
    r = client.call_tool("edit_starting_pawn", {"action": "reroll", "index": INDEX})
    if not r.get("ok"):
        print("reroll failed:", json.dumps(r)[:200])
        break
    pawn = [p for p in r["pawns"] if p["index"] == INDEX][0]
    problems, sk = verdict(pawn)
    print(f"{attempt:2d} {pawn['name']:22s} plants={sk.get('plants')} medical={sk.get('medical')} "
          f"shooting={sk.get('shooting')} melee={sk.get('melee')} -> {'KEEP' if not problems else ', '.join(problems)}")
    if not problems:
        print("CHOSEN:", pawn["name"], json.dumps(sk))
        break
