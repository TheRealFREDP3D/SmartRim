import json, requests
URL = "http://localhost:8787/"


def call(n, a=None):
    p = {"jsonrpc": "2.0", "id": 1, "method": "tools/call", "params": {"name": n, "arguments": a or {}}}
    r = requests.post(URL, json=p, timeout=30)
    d = r.json()
    t = d["result"]["content"][0]["text"]
    try:
        return json.loads(t)
    except Exception:
        return {"text": t}


MATTHEW = "Matthew Po"
CAMI = "Camilla 'Cami' Maney"
ANDY = "Andrew 'Andy' Camden"

plans = {
    MATTHEW: [("Firefighter", 1), ("Patient", 1), ("Research", 1), ("Construction", 3), ("Crafting", 3),
              ("Cooking", 4), ("Growing", 4), ("PlantCutting", 4), ("Mining", 4), ("Cleaning", 3),
              ("Hauling", 3), ("Hunting", 2)],
    CAMI: [("Firefighter", 1), ("Patient", 1), ("Cooking", 1), ("Doctor", 1), ("Construction", 2),
           ("Growing", 3), ("PlantCutting", 3), ("Hauling", 2), ("Cleaning", 3), ("Mining", 4),
           ("Hunting", 3), ("Crafting", 4), ("Research", 4)],
    ANDY: [("Firefighter", 1), ("Patient", 1), ("Construction", 1), ("Hunting", 2), ("PlantCutting", 2),
           ("Hauling", 2), ("Cleaning", 3), ("Mining", 3), ("Growing", 4), ("Cooking", 4),
           ("Crafting", 3), ("Doctor", 2), ("Research", 4)],
}

for name, wts in plans.items():
    for wt, p in wts:
        call("set_work_priority", {"name": name, "workType": wt, "priority": p})
print("priorities set")
