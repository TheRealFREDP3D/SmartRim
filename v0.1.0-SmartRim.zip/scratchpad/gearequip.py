import json, requests
URL="http://localhost:8787/"
def call(n,a=None):
    p={'jsonrpc':'2.0','id':1,'method':'tools/call','params':{'name':n,'arguments':a or {}}}
    r=requests.post(URL,json=p,timeout=30)
    d=r.json(); t=d['result']['content'][0]['text']
    try: return json.loads(t)
    except: return {'text':t}

# Byte: rifle
print('Byte rifle:', call('manage_gear',{'name':"Dominic 'Byte' Byter",'op':'equip','item':'Gun_BoltActionRifle4917'}))
# Beka: knife
print('Beka knife:', call('manage_gear',{'name':'Beka Pham','op':'equip','item':'MeleeWeapon_Knife4919'}))
# Tiger: revolver
print('Tiger revolver:', call('manage_gear',{'name':"Ticer 'Tiger' Nelson",'op':'equip','item':'Gun_Revolver4918'}))
# Apparel
print('Byte flakvest:', call('manage_gear',{'name':"Dominic 'Byte' Byter",'op':'equip','item':'Apparel_FlakVest4921'}))
print('Byte flakpants:', call('manage_gear',{'name':"Dominic 'Byte' Byter",'op':'equip','item':'Apparel_FlakPants4920'}))
print('Byte helmet:', call('manage_gear',{'name':"Dominic 'Byte' Byter",'op':'equip','item':'Apparel_AdvancedHelmet4922'}))
print('Beka flakvest2:', call('manage_gear',{'name':'Beka Pham','op':'equip','item':'Apparel_FlakVest4921'}))