import json, sys
sys.path.insert(0, r"C:\Users\fred\Desktop\RimWorld Consellor\RimAutonomous\sidecar")
from counselor import _call

MATTHEW = "Matthew Po"
CAMI = "Camilla 'Cami' Maney"
ANDY = "Andrew 'Andy' Camden"

# Knife is at (140,140) - MeleeWeapon_Knife3755
print("Cami knife:", _call("manage_gear", {"name": CAMI, "op": "equip", "item": "MeleeWeapon_Knife3755"}).get("ok"))

# Check each colonist's full state
for name in (MATTHEW, CAMI, ANDY):
    st = _call("get_status")
    cid = [c["id"] for c in st["bundled"]["list_colonists"]["colonists"] if c["name"] == name][0]
    g = _call("get_pawn", {"id": cid})
    print(name, "weapon=", g.get("weapon"), "apparel=", g.get("apparel"))

# Targeted medicine search: small grid around the home area
WANT = ("MedicineIndustrial", "Gun_", "Apparel_", "Silver")
hits = {}
for z in range(133, 147):
    for x in range(136, 150):
        r = _call("inspect_thing", {"x": x, "z": z})
        iid = r.get("id") or ""
        if iid.startswith(WANT):
            hits[iid] = (x, z, r.get("label"))
print("gear/medicine found:", hits)
