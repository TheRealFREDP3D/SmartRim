import json, requests
URL="http://localhost:8787/"
def call(n,a=None):
    p={'jsonrpc':'2.0','id':1,'method':'tools/call','params':{'name':n,'arguments':a or {}}}
    r=requests.post(URL,json=p,timeout=30)
    d=r.json(); t=d['result']['content'][0]['text']
    try: return json.loads(t)
    except: return {'text':t}

st=call('get_status')
ids={c['name']:c['id'] for c in st['bundled']['list_colonists']['colonists']}
tyren=ids['Tyren Nordgren']
henry=ids["Henry 'Lawman' Jensen"]
print('undraft:', call('draft',{'action':'undraft','ids':tyren+','+henry}))
print('Tyren knife:', call('manage_gear',{'name':'Tyren Nordgren','op':'equip','item':'MeleeWeapon_Knife4218'}))
print('Tyren vest:', call('manage_gear',{'name':'Tyren Nordgren','op':'wear','item':'Apparel_FlakVest4220'}))
