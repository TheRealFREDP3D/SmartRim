"""List architect designators by category (no truncation)."""
import json
import sys

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.path.insert(0, "sidecar")
from mcp_client import McpClient
from config import MCP_URL, MCP_DELAY

c = McpClient(MCP_URL, delay=MCP_DELAY)
cat = sys.argv[1] if len(sys.argv) > 1 else "Orders"
r = c.call_tool("list_architect", {"category": cat})
for d in r.get("designators", []):
    print(f"{d['type']:45s} {d['label']:28s} buildDef={d.get('buildDef')}")
