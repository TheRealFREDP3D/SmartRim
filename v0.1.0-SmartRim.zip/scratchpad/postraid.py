import json, requests
URL="http://localhost:8787/"
def call(n,a=None):
    p={'jsonrpc':'2.0','id':1,'method':'tools/call','params':{'name':n,'arguments':a or {}}}
    r=requests.post(URL,json=p,timeout=30)
    d=r.json(); t=d['result']['content'][0]['text']
    try: return json.loads(t)
    except: return {'text':t}

st=call('get_status')
henry=[c['id'] for c in st['bundled']['list_colonists']['colonists'] if c['name']=="Henry 'Lawman' Jensen"][0]
print('undraft Henry:', call('draft',{'action':'undraft','ids':henry}))
msg='=== RAID OVER ===\nPollution Unit raider "Swamp" killed. Tyren wounded (79->80 HP, knife wounds). Tending/healing in progress.\nAll colonists alive. Need to haul the corpse and strip loot. Continuing.'
print(call('say',{'text':msg})['shown'])
