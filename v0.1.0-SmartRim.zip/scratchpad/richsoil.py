import json, requests
URL="http://localhost:8787/"
def call(n,a=None):
    p={'jsonrpc':'2.0','id':1,'method':'tools/call','params':{'name':n,'arguments':a or {}}}
    r=requests.post(URL,json=p,timeout=30)
    d=r.json(); t=d['result']['content'][0]['text']
    try: return json.loads(t)
    except: return {'text':t}

for x in range(120,160,10):
    for z in range(100,130,10):
        a=call('get_area',{'minX':x,'minZ':z,'maxX':x+9,'maxZ':z+9,'summary':True})
        ts=a.get('terrainSummary',{})
        if ts.get('SoilRich',0)>0:
            print('rich soil at x=%d-%d z=%d-%d: %d cells' % (x,x+9,z,z+9,ts.get('SoilRich')))
