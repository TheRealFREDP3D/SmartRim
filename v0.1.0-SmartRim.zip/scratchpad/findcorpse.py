import json, requests
URL="http://localhost:8787/"
def call(n,a=None):
    p={'jsonrpc':'2.0','id':1,'method':'tools/call','params':{'name':n,'arguments':a or {}}}
    r=requests.post(URL,json=p,timeout=30)
    d=r.json(); t=d['result']['content'][0]['text']
    try: return json.loads(t)
    except: return {'text':t}

for z in range(107,113):
    for x in range(127,133):
        r=call('inspect_thing',{'x':x,'z':z})
        lab=r.get('label') or ''
        if 'Corpse' in lab or 'corpse' in lab.lower() or 'Swamp' in lab:
            print('(%d,%d): %s %s' % (x,z,lab,r.get('id')))
print('done')
