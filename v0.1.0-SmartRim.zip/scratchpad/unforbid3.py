import json, requests, time, sys

URL="http://localhost:8787/"
def call(n,a=None):
    p={'jsonrpc':'2.0','id':1,'method':'tools/call','params':{'name':n,'arguments':a or {}}}
    r=requests.post(URL,json=p,timeout=30)
    d=r.json(); t=d['result']['content'][0]['text']
    try: return json.loads(t)
    except: return {'text':t}

ids=[]; off=0; total=0
while True:
    r=call('list_things',{'category':'item','limit':50,'offset':off})
    th=r.get('things',[])
    if not th: break
    total+=len(th)
    for t in th:
        if t.get('forbidden') is True:
            ids.append(t['id'])
    off+=len(th)
    sys.stdout.write(f'page off={off} total={total} forb={len(ids)}\n'); sys.stdout.flush()
    if len(th)<50: break
    time.sleep(0.2)

sys.stdout.write(f'TOTAL items={total} forbidden={len(ids)}\n'); sys.stdout.flush()

done=0
for iid in ids:
    try:
        call('do_thing_action',{'id':iid,'label':'Allow'})
        done+=1
    except Exception as e:
        sys.stdout.write(f'err {iid} {e}\n'); sys.stdout.flush()
    time.sleep(0.2)
sys.stdout.write(f'UNFORBIDDEN={done}\n'); sys.stdout.flush()
