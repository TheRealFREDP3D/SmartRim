import json
import sys

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

PATH = "memory/lessons.jsonl"

REC = {
    "id": "L-0053",
    "title": "A hard-killed game leaks [::1]:8787 and the relaunched game cannot bind its MCP server",
    "trigger": {
        "phases": ["stabilization", "expansion", "crisis"],
        "threats": [],
        "resources": [],
        "difficulty": [],
        "storyteller": [],
        "biome": [],
    },
    "recommendation": (
        "If the MCP client gets connection refused while RimWorld is running, check Player.log for "
        "'Failed to start MCP server' and run netstat -ano | findstr :8787. A LISTENING entry on [::1]:8787 "
        "whose PID no longer exists is a leaked socket from the previous game process; no amount of client "
        "retrying fixes it. RimMolt has no port setting and starts its server only at startup, so the fixes "
        "are a reboot (clears the orphan) or patching the mod. Test ::1:8787 and 0.0.0.0:8787 separately - "
        "IPv4 can be bindable while IPv6 loopback is not, so a single failed bind is not proof the port is free."
    ),
    "rationale": (
        "run-003 day 9: the game process started 18 Oct died at 01:30 and the 19:07 relaunch logged 1449 "
        "WSAEADDRINUSE failures, then stopped retrying. Confirmed with an explicit Python bind test: "
        "::1:8787 => WinError 10048, 0.0.0.0:8787 => OK. Nothing in WSL listened on the port and there was "
        "no HTTP.sys urlacl. Recovery was a machine reboot plus reloading the last manual save; the run log "
        "records it as crash recovery, not a reload-rewind."
    ),
    "source": ["run-003 session log", "Player.log diagnosis 2026-10-20"],
    "confidence": 0.9,
    "tags": ["mcp_gotcha", "harness", "infrastructure"],
    "times_applied": 0,
    "times_helped": 0,
    "times_failed": 0,
    "status": "active",
    "source_runs": ["run-003"],
    "last_updated": "2026-10-21",
}

lines = [l for l in open(PATH, encoding="utf-8") if l.strip()]
if any(json.loads(l)["id"] == REC["id"] for l in lines):
    print("already present, nothing to do")
else:
    with open(PATH, "a", encoding="utf-8") as f:
        f.write(json.dumps(REC, ensure_ascii=False) + "\n")
    print("appended, total lessons:", len(lines) + 1)
