"""Search architect buildables by keyword across categories."""
import json
import sys

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.path.insert(0, "sidecar")
from mcp_client import McpClient
from config import MCP_URL, MCP_DELAY

c = McpClient(MCP_URL, delay=MCP_DELAY)
needle = (sys.argv[1] if len(sys.argv) > 1 else "butcher").lower()
cats = [x["defName"] for x in c.call_tool("list_architect", {})["categories"]]
for cat in cats:
    try:
        r = c.call_tool("list_architect", {"category": cat})
    except Exception:
        continue
    for d in r.get("designators", []):
        hay = f"{d.get('type','')} {d.get('label','')} {d.get('buildDef') or ''}".lower()
        if needle in hay:
            print(f"{cat:12s} {d.get('type',''):40s} {d.get('label',''):24s} buildDef={d.get('buildDef')}")
