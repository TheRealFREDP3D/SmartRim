"""Quick colony housekeeping: lighting check, priorities, meal bill."""
import json
import re
import sys

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.path.insert(0, "sidecar")
from mcp_client import McpClient
from config import MCP_URL, MCP_DELAY

c = McpClient(MCP_URL, delay=MCP_DELAY)

for tid in ("TorchLamp53371", "TorchLamp52879", "TorchLamp49555", "TorchLamp49648"):
    r = c.call_tool("get_info_card", {"id": tid})
    s = json.dumps(r, ensure_ascii=False)
    fuel = re.findall(r"[^\"]{0,40}(?:fuel|Fuel)[^\"]{0,50}", s)
    print(tid, fuel[:2])

light = c.call_tool(
    "get_area",
    {"minX": 158, "minZ": 125, "maxX": 166, "maxZ": 133, "render": "ascii", "layer": "light"},
)
print("light rows z133->125:", json.dumps(light.get("grid"), ensure_ascii=False))
