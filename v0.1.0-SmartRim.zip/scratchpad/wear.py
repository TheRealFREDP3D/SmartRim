import json, requests
URL="http://localhost:8787/"
def call(n,a=None):
    p={'jsonrpc':'2.0','id':1,'method':'tools/call','params':{'name':n,'arguments':a or {}}}
    r=requests.post(URL,json=p,timeout=30)
    d=r.json(); t=d['result']['content'][0]['text']
    try: return json.loads(t)
    except: return {'text':t}

# Beka (melee): flak vest + flak pants
print('Beka vest:', call('manage_gear',{'name':'Beka Pham','op':'wear','item':'Apparel_FlakVest4921'}))
print('Beka pants:', call('manage_gear',{'name':'Beka Pham','op':'wear','item':'Apparel_FlakPants4920'}))
# Tiger (medic): flak helmet
print('Tiger helmet:', call('manage_gear',{'name':"Ticer 'Tiger' Nelson",'op':'wear','item':'Apparel_AdvancedHelmet4922'}))
# Byte (researcher): duster
print('Byte duster:', call('manage_gear',{'name':"Dominic 'Byte' Byter",'op':'wear','item':'Apparel_Duster4924'}))
