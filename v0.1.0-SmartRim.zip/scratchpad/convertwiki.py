import os, html2text
CACHE = r"C:\Users\fred\Desktop\RimWorld Consellor\RimAutonomous\memory\wiki"
h = html2text.HTML2Text()
h.ignore_links = False
h.body_width = 0
count = 0
for fn in os.listdir(CACHE):
    if fn.endswith(".html"):
        path = os.path.join(CACHE, fn)
        md_path = os.path.join(CACHE, fn.replace(".html", ".md"))
        try:
            html = open(path, encoding="utf-8").read()
            md = h.handle(html)
            with open(md_path, "w", encoding="utf-8") as f:
                f.write(md)
            count += 1
        except Exception as e:
            print("FAIL", fn, str(e)[:60])
print("converted", count, "files to markdown")
