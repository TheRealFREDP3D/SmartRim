import json, requests, time, os

URL = "http://localhost:8787/"
def call(n,a=None):
    p={'jsonrpc':'2.0','id':1,'method':'tools/call','params':{'name':n,'arguments':a or {}}}
    r=requests.post(URL,json=p,timeout=10)
    d=r.json(); t=d['result']['content'][0]['text']
    try: return json.loads(t)
    except: return {'text':t}

ids=[]
off=0
while True:
    r=call('list_things',{'category':'item','limit':200,'offset':off})
    th=r.get('things',[])
    if not th: break
    for t in th:
        if t.get('forbidden'):
            ids.append(t['id'])
    off+=len(th)
    if len(th)<200: break
    time.sleep(0.2)

print('forbidden count:', len(ids))
# unforbid all
done=0
for iid in ids:
    try:
        call('do_thing_action',{'id':iid,'label':'Allow'})
        done+=1
    except Exception as e:
        print('err', iid, e)
print('unforbidden:', done)
# save
out=os.path.join(os.environ.get('TEMP','.'),'forbidden_ids.json')
with open(out,'w') as f: json.dump(ids,f)
print('saved', out)
