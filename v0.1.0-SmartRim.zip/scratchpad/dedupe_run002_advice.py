"""One-off: mark the run-002 startup-burst duplicate urgent records as invalid.

The monitor wrote 99 identical open urgent records ("Medicine stock low (0); Food
stock low (0 units)") between 07:16 and 07:29 while the game was not loaded.
Keep the first record, mark the rest invalid with a note so evaluation counts are not
inflated. Run once: python scratchpad/dedupe_run002_advice.py
"""

import json

PATH = "memory/advice/advice.jsonl"
RUN = "run-002-adv-cassandra"
TARGET = "Medicine stock low (0); Food stock low (0 units)"

recs = [json.loads(line) for line in open(PATH, encoding="utf-8") if line.strip()]
match = [r for r in recs if r.get("run_id") == RUN and r.get("situation") == TARGET and r.get("status") == "open"]
print("total records:", len(recs), "matching open burst:", len(match))
if match:
    print("window:", match[0]["timestamp"], "->", match[-1]["timestamp"])

keep = match[0]["advice_id"] if match else None
marked = 0
for rec in recs:
    if rec.get("advice_id") == keep:
        rec["outcome_note"] = "startup burst (game not loaded): medicine/food readout returned 0; kept as the first occurrence"
        continue
    if rec.get("run_id") == RUN and rec.get("situation") == TARGET and rec.get("status") == "open":
        rec["status"] = "invalid"
        rec["outcome_note"] = "duplicate startup-burst record (game not loaded, readout 0); excluded from evaluation"
        marked += 1

with open(PATH, "w", encoding="utf-8") as f:
    for rec in recs:
        f.write(json.dumps(rec, default=str) + "\n")
print("marked invalid:", marked)
