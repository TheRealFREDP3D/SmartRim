import json, time, urllib.request, urllib.error

BASE = "http://localhost:11434"
PROMPT = """You are reviewing a RimWorld colony run.

Colony data:
- Day 5: 3 colonists, food 12 units, medicine 0; alerts: food_low, medicine_low.
- Day 6: raid (3 raiders); 1 colonist downed; food 4.
- Day 7: colony wiped (all colonists dead).

Task: Return ONLY a JSON object with these keys:
  "primary_cause" (string),
  "worked" (array of strings),
  "lessons" (array of strings, max 3),
  "next_steps" (array of strings).
No markdown, no extra text."""

REQUIRED = ["primary_cause", "worked", "lessons", "next_steps"]
KEYWORDS = ["raid", "food", "medicine", "defense", "doctor", "stock"]

def api_tags():
    with urllib.request.urlopen(BASE + "/api/tags", timeout=30) as r:
        return json.loads(r.read())["models"]

def is_chat(m):
    caps = m.get("capabilities") or []
    if "completion" not in caps:
        return False
    if "embedding" in caps and "completion" not in caps:
        return False
    return True

def run_model(name):
    payload = {
        "model": name,
        "prompt": PROMPT,
        "stream": False,
        "think": False,
        "keep_alive": 0,
        "options": {"temperature": 0, "num_ctx": 4096, "num_predict": 512},
    }
    data = json.dumps(payload).encode()
    req = urllib.request.Request(BASE + "/api/generate", data=data, headers={"Content-Type": "application/json"})
    t0 = time.time()
    try:
        with urllib.request.urlopen(req, timeout=300) as resp:
            obj = json.loads(resp.read())
    except Exception as e:
        return {"model": name, "error": str(e)}
    total = time.time() - t0
    text = (obj.get("response") or "").strip()
    # score
    score = 0
    notes = []
    parsed = None
    try:
        # strip fences
        s = text
        if s.startswith("```"):
            s = s.strip().strip("`")
            if s.lower().startswith("json"):
                s = s[4:].strip()
        parsed = json.loads(s)
        score += 2  # valid json
        notes.append("valid_json")
    except Exception:
        notes.append("invalid_json")
    if isinstance(parsed, dict):
        for k in REQUIRED:
            if k in parsed:
                score += 1
        if isinstance(parsed.get("lessons"), list) and len(parsed["lessons"]) <= 3:
            score += 1
        if isinstance(parsed.get("worked"), list) and parsed["worked"]:
            score += 1
        if isinstance(parsed.get("next_steps"), list) and parsed["next_steps"]:
            score += 1
        blob = (str(parsed.get("primary_cause","")) + " " + " ".join(map(str, parsed.get("lessons",[]))) + " " + " ".join(map(str, parsed.get("next_steps",[])))).lower()
        kw = sum(1 for k in KEYWORDS if k in blob)
        score += kw  # up to 6
        if kw >= 2:
            notes.append(f"keywords={kw}")
    # penalty for extra markdown
    if "```" in text:
        score -= 1
        notes.append("had_fences")
    toks = obj.get("eval_count", 0)
    eval_dur = obj.get("eval_duration", 1) / 1e9
    tps = toks / eval_dur if eval_dur > 0 else 0
    return {
        "model": name,
        "total_s": round(total, 1),
        "tok_s": round(tps, 2),
        "eval_tokens": toks,
        "score": score,
        "notes": ",".join(notes),
        "preview": text[:200].replace("\n", " "),
    }

def main():
    models = api_tags()
    # dedupe by digest
    seen = set()
    chat_models = []
    for m in models:
        if not is_chat(m):
            continue
        d = m.get("digest")
        if d in seen:
            continue
        seen.add(d)
        chat_models.append(m["name"])
    # sort by size? keep list order (as returned)
    print("Benchmarking models:", chat_models)
    results = []
    for name in chat_models:
        print(f"\n=== {name} ===", flush=True)
        r = run_model(name)
        results.append(r)
        if "error" in r:
            print("ERROR:", r["error"])
        else:
            print(f"total={r['total_s']}s tok/s={r['tok_s']} score={r['score']} notes={r['notes']}")
            print("preview:", r["preview"])
    # save
    out = "C:/Users/fred/Desktop/RimWorld Consellor/RimAutonomous/scratchpad/bench_results.json"
    with open(out, "w") as f:
        json.dump(results, f, indent=2)
    # print sorted table
    ok = [r for r in results if "error" not in r]
    ok.sort(key=lambda r: r["score"], reverse=True)
    print("\n\n=== RESULTS (sorted by score desc) ===")
    print(f"{'model':45} {'score':>5} {'tok/s':>7} {'total_s':>8}  notes")
    for r in ok:
        print(f"{r['model']:45} {r['score']:>5} {r['tok_s']:>7} {r['total_s']:>8}  {r['notes']}")
    if len(ok) >= 2:
        # trade-off: score per second? compute score/(total_s) 
        best = max(ok, key=lambda r: r["score"] / max(r["total_s"], 0.1))
        print("\nBest trade-off (score/total_time):", best["model"], best["score"], best["total_s"])

if __name__ == "__main__":
    main()
