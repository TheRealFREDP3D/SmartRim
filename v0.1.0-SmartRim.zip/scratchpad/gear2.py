import json, requests
URL="http://localhost:8787/"
def call(n,a=None):
    p={'jsonrpc':'2.0','id':1,'method':'tools/call','params':{'name':n,'arguments':a or {}}}
    r=requests.post(URL,json=p,timeout=30)
    d=r.json(); t=d['result']['content'][0]['text']
    try: return json.loads(t)
    except: return {'text':t}

# Chaz: rifle + duster
print('Chaz rifle:', call('manage_gear',{'name':'Chaz Targrin','op':'equip','item':'Gun_BoltActionRifle4216'}))
print('Chaz duster:', call('manage_gear',{'name':'Chaz Targrin','op':'wear','item':'Apparel_Duster4224'}))
# Tyren: knife + flak vest + flak pants
print('Tyren knife:', call('manage_gear',{'name':'Tyren Nordgren','op':'equip','item':'MeleeWeapon_Knife4218'}))
print('Tyren vest:', call('manage_gear',{'name':'Tyren Nordgren','op':'wear','item':'Apparel_FlakVest4220'}))
print('Tyren pants:', call('manage_gear',{'name':'Tyren Nordgren','op':'wear','item':'Apparel_FlakPants4219'}))
# Henry: revolver + flak helmet
print('Henry revolver:', call('manage_gear',{'name':"Henry 'Lawman' Jensen",'op':'equip','item':'Gun_Revolver4217'}))
print('Henry helmet:', call('manage_gear',{'name':"Henry 'Lawman' Jensen",'op':'wear','item':'Apparel_AdvancedHelmet4221'}))
