import json, os, time, urllib.request

BASE = "https://rimworldwiki.com/wiki/"
CACHE = r"C:\Users\fred\Desktop\RimWorld Consellor\RimAutonomous\memory\wiki"
os.makedirs(CACHE, exist_ok=True)

# Retry failed slugs with alternatives + fetch additional pages
PAGES = [
    # retries
    "Cooler",
    "Heater",
    "Temperature",
    "Hunting",
    "Smithing",
    "Lighting",
    "Lamps",
    "Base",
    "Base_building",
    # additional important pages
    "Sowing",
    "Harvest",
    "Butchering",
    "Cooking",
    "Meals",
    "Nutrient_paste",
    "Recreation",
    "Bed",
    "Bedroom",
    "Stockpile_zone",
    "Growing_zone",
    "Medical_bed",
    "Hospital",
    "Doctoring",
    "Surgery",
    "Tending",
    "Infection",
    "Disease",
    "Plague",
    "Malaria",
    "Flu",
    "Injury",
    "Blood_loss",
    "Pain",
    "Mental_break",
    "Inspiration",
    "Joy",
    "Joywire",
    "Drug",
    "Beer",
    "Smokeleaf",
    "Luciferium",
    "Psychite",
    "Yayo",
    "Flake",
    "Go-juice",
    "Wake-up",
    "Penoxycyline",
    "Ambrosia",
    "Neutroamine",
    "Cloth",
    "Cotton",
    "Devilstrand",
    "Hyperweave",
    "Synthread",
    "Megasloth_wool",
    "Alpaca_wool",
    "Muffalo_wool",
    "Camel_wool",
    "Wool",
    "Leather",
    "Hide",
    "Fur",
    "Pelt",
    "Meat",
    "Human_meat",
    "Insect_meat",
    "Raw_food",
    "Simple_meal",
    "Fine_meal",
    "Lavish_meal",
    "Packaged_survival_meal",
    "Kibble",
    "Hay",
    "Fodder",
    "Animal_feed",
    "Taming",
    "Training",
    "Bond",
    "Release",
    "Slaughter",
    "Shear",
    "Milking",
    "Egg",
    "Wool",
    "Hauling",
    "Cleaning",
    "Firefighting",
    "Construction",
    "Mining",
    "Growing",
    "Plant_cutting",
    "Crafting",
    "Smithing",
    "Tailoring",
    "Art",
    "Research",
    "Intellectual",
    "Social",
    "Animals_skill",
    "Medicine_skill",
    "Cooking_skill",
    "Shooting",
    "Melee",
    "Ranged",
    "Brawler",
    "Sniper",
    "Careful_shooter",
    "Trigger-happy",
    "Nimble",
    "Tough",
    "Robust",
    "Delicate",
    "Frail",
    "Sickly",
    "Immune",
    "Disease_resistance",
    "Immunity",
    "Infection_chance",
    "Treatment_quality",
    "Medicine",
    "Herbal_medicine",
    "Glitterworld_medicine",
    "Industrial_medicine",
    "Animal_medicine",
    "Vet_medicine",
    "Surgery",
    "Organ",
    "Prosthetic",
    "Bionic",
    "Archotech",
    "Peg_leg",
    "Simple_prosthetic",
    "Bionic_arm",
    "Bionic_leg",
    "Bionic_eye",
    "Bionic_heart",
    "Bionic_kidney",
    "Bionic_lung",
    "Power_claw",
    "Scyther_blade",
    "Drill_arm",
    "Field_hand",
    "Hand_talon",
    "Venom_fang",
    "Venom_talon",
    "Mind_worm",
    "Psychic_soothe_pulser",
    "Psychic_animal_pulser",
    "Psychic_emanator",
    "Psychic_drone",
    "Psychic_scream",
    "Psychic_ship",
    "Psychic_artifact",
    "Archotech_artifact",
    "Mechanoid",
    "Scyther",
    "Lancer",
    "Centipede",
    "Pikeman",
    "Termite",
    "Inferno_cannon",
    "Heavy_charge_blaster",
    "Charge_lance",
    "Charge_rifle",
    "Minigun",
    "Doomsday_rocket_launcher",
    "Triple_rocket_launcher",
    "Incendiary_launcher",
    "Smoke_launcher",
    "EMI_launcher",
    "Toxic_launcher",
    "Antigrain_warhead",
    "Orbital_beam_targeter",
    "Orbital_power_beam_targeter",
    "Tornado_generator",
    "Weather_controller",
    "Climate_adjuster",
    "Vanometric_power_cell",
    "Infinite_chemreactor",
    "Techprof_subpersona_core",
    "AI_core",
    "AI_persona_core",
    "Mechanitor",
    "Mechlink",
    "Mech",
    "Constructoid",
    "Paramedic",
    "Agrihand",
    "Lifter",
    "Cleansweeper",
    "Fabricor",
    "Militor",
    "Scorcher",
    "Tunneler",
    "War_urchin",
    "War_queen",
    "Apocriton",
    "Diabolus",
    "Centurion",
    "Overseer",
    "Gestator",
    "Band_node",
    "Wastepack",
    "Tox tox",
    "Toxic",
    "Pollution",
    "Wastepack",
    "Rimworld",
]

manifest = {}
manifest_path = os.path.join(CACHE, "manifest.json")
if os.path.exists(manifest_path):
    try:
        manifest = json.load(open(manifest_path))
    except Exception:
        manifest = {}

ok = 0
fail = 0
for slug in PAGES:
    url = BASE + slug.replace(" ", "_")
    out_html = os.path.join(CACHE, slug.replace(" ", "_") + ".html")
    out_md = os.path.join(CACHE, slug.replace(" ", "_") + ".md")
    if os.path.exists(out_md):
        # already cached, skip
        continue
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "RimWorldCounselor/1.0"})
        with urllib.request.urlopen(req, timeout=30) as resp:
            html = resp.read().decode("utf-8", errors="replace")
        with open(out_html, "w", encoding="utf-8") as f:
            f.write(html)
        # convert to md
        try:
            import html2text
            h = html2text.HTML2Text()
            h.ignore_links = False
            h.body_width = 0
            md = h.handle(html)
            with open(out_md, "w", encoding="utf-8") as f:
                f.write(md)
        except Exception:
            pass
        manifest[slug.replace(" ", "_")] = {"url": url, "fetched": time.strftime("%Y-%m-%d"), "size": len(html)}
        ok += 1
        print("OK", slug, len(html))
    except Exception as e:
        fail += 1
        print("FAIL", slug, str(e)[:60])
    time.sleep(0.4)

with open(manifest_path, "w", encoding="utf-8") as f:
    json.dump(manifest, f, indent=2)
print("done: ok=%d fail=%d manifest=%d" % (ok, fail, len(manifest)))
