# RESUME AFTER REBOOT — run-003 (adviser off)

Written 20 Oct 2026 ~19:55 real time, immediately before a planned machine reboot.

## Why the reboot

RimWorld was relaunched at 19:07 after the run-003 game process died at ~01:30.
RimMolt could not start its server:

```
[RimMolt] Failed to start MCP server on port 8787: Only one usage of each socket address ...
```

Root cause: leaked IPv6 listener `[::1]:8787 LISTENING` owned by PID 28536 (the dead game process,
socket created 18 Oct 09:04:59). Verified: bind on `::1:8787` fails (WinError 10048) while
`0.0.0.0:8787` binds fine. No WSL listener, no HTTP.sys urlacl, no port setting in RimMolt.

The reboot clears the orphaned socket. This is crash recovery, **not** a reload-rewind — no in-game
decision is taken back. Full writeup: `memory/session-logs/run-003-adv-cassandra.md`
("Incident: MCP outage and crash recovery"). Lesson recorded as **L-0053**.

## Steps

1. Launch RimWorld (mods unchanged) and load **`The Seekers.rws`** — the manual save at
   **20 Oct 01:30** (day 9, 15 Septober ~07h). Do not load `Autosave-3` or older.
2. Check MCP is back:
   ```powershell
   cd "C:\Users\fred\Desktop\RimWorld Consellor\RimAutonomous"
   python scratchpad/mcp.py get_status
   ```
   If it still refuses, check `netstat -ano | findstr :8787` and Player.log again (L-0053).
3. Restart the observe-only monitor (kill any duplicates first — two were running before the reboot):
   ```powershell
   $env:RUN_ID="run-003-adv-cassandra"
   .venv\Scripts\python.exe -u sidecar\monitor.py --observe-only
   ```
4. Sanity check the colony at day 9: Urist / Sera / Remy alive, `daysPassed` 9, moods ~34/80/80,
   rice ~298, smokeleaf stock, 3 passive coolers, no raid pending.

## Where run-003 stands

- Arm: adviser **off**. No advice records, no auto-pauses. End marker must carry
  `arm: "off"`, `auto_pauses: 0`.
- Research line (must mirror run-002): Smithing → LongBlades → PlateArmor → Batteries.
  Smithing was ~93% on day 8.
- Urist is the risk: fibrous mechanites (pain −15, severity 0.84 and climbing), bonded cat killed
  (−8), greedy (−8). Give a smokeleaf joint each time the ~11h high expires; keep his room cooled.
- Cooking was just fixed (Remy Cooking priority 1 + bulk simple-meal bill x4 target 30).
- Deliberately ignored, keep ignoring: Mechanoid Signal, The Ambushed Praetor, fallen monolith,
  sealed ruin / ancient danger near x146-152 z140-150.
- Harvest rice field 2 around 15-16 Sept. Wood was thin (~160).
- Next raid: draft all three, fight in the open (wave 1 was a lone melee raider).

## Closing run-003 (at `daysPassed` 11)

1. Tag causes: `python sidecar/advice_log.py cause-match run-003-adv-cassandra <needle> "<text>"`
2. Generate the bundle (v3) and confirm `arm: "off"`, `auto_pauses: 0`.
3. Note the day-9 infrastructure interruption as an anomaly in the run metadata and scorecard —
   it is not a colonist-caused outcome.
