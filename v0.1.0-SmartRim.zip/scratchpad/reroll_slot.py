"""Reroll one starting slot in place until it meets the run's team rule.

Modes: fighter (shooting 5+), shooter (shooting 5+), support (medical 5+ or plants 5+).
No reordering: the last attempt at reordering dropped a colonist at spawn.
"""
import json
import re
import sys

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.path.insert(0, "sidecar")
from mcp_client import McpClient
from config import MCP_URL, MCP_DELAY

INDEX = int(sys.argv[1])
MODE = sys.argv[2] if len(sys.argv) > 2 else "shooter"
TRIES = int(sys.argv[3]) if len(sys.argv) > 3 else 20
c = McpClient(MCP_URL, delay=MCP_DELAY)


def skills_of(pawn):
    out = {}
    for item in pawn.get("skills") or []:
        if isinstance(item, dict):
            out[item.get("skill")] = item.get("level")
            continue
        m = re.match(r"([a-z]+)\s+(\d+)", str(item))
        if m:
            out[m.group(1)] = int(m.group(2))
    return out


def problems_for(pawn, mode):
    incap = str(pawn.get("incapableOf") or "")
    traits = " ".join(t.get("label", "") if isinstance(t, dict) else str(t) for t in pawn.get("traits") or [])
    health = " ".join(str(h) for h in pawn.get("health") or [])
    sk = skills_of(pawn)
    out = []
    for banned in ("Violent", "Caring", "Firefighting"):
        if banned in incap:
            out.append("incapable " + banned)
    for bad in ("Pyromaniac", "Misogynist", "Cannibal", "Wimp"):
        if bad in traits:
            out.append(bad.lower())
    if "peg leg" in health.lower() or "Removed" in health or "Frail" in health:
        out.append("leg/frail")
    if "Pregnant" in health:
        out.append("pregnant")
    if mode in ("fighter", "shooter") and sk.get("shooting", 0) < 5:
        out.append("shooting<5")
    if mode == "support" and sk.get("medical", 0) < 5 and sk.get("plants", 0) < 5:
        out.append("no doctor/grower")
    return out, sk


for attempt in range(1, TRIES + 1):
    r = c.call_tool("edit_starting_pawn", {"action": "reroll", "index": INDEX})
    pawn = [p for p in r.get("pawns", []) if p["index"] == INDEX]
    if not pawn:
        print("reroll failed", json.dumps(r)[:200])
        break
    pawn = pawn[0]
    probs, sk = problems_for(pawn, MODE)
    print(f"{attempt:2d} {pawn['name']:24s} shoot={sk.get('shooting')} melee={sk.get('melee')} "
          f"con={sk.get('construction')} plants={sk.get('plants')} med={sk.get('medical')} "
          f"int={sk.get('intellectual')} -> {'KEEP' if not probs else ','.join(probs)}")
    if not probs:
        print("CHOSEN", INDEX, pawn["name"], json.dumps(sk))
        break
