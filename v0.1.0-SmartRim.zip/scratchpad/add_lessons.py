import json

path = "memory/lessons.jsonl"
rows = [json.loads(l) for l in open(path, encoding="utf-8") if l.strip()]
next_id = max(int(r["id"].split("-")[1]) for r in rows) + 1


def trig(phases=(), threats=(), resources=(), difficulty=(), storyteller=(), biome=()):
    return {"phases": list(phases), "threats": list(threats), "resources": list(resources),
            "difficulty": list(difficulty), "storyteller": list(storyteller), "biome": list(biome)}


new = [
    {
        "title": "Vanilla research cannot be queued: the next project is a hand decision",
        "trigger": trig(phases=("early_survival", "stabilization")),
        "recommendation": "Do not plan a multi-project queue; it does not exist. Pick the next project in advance so it can be set the instant the current one completes, and treat the 'Need research project' alert as lost research hours.",
        "rationale": "run-002: 'Need research project' appeared on 12th Aprimay after many completed projects. The player confirmed a project cannot be queued in vanilla, so the gap is a decision-timing problem, not a forgotten click.",
        "source": ["run-002-adv-cassandra.md", "player correction 2026-10-19"],
        "confidence": 0.8,
        "tags": ["research", "ui", "planning"],
    },
    {
        "title": "A protection-quest target is an escorted liability, not a colonist to integrate",
        "trigger": trig(phases=("stabilization", "expansion"), threats=("raid", "predator"), resources=("any")),
        "recommendation": "For 'protect X' quests: restrict the target's allowed area to the base, give them food they accept and a weapon if they can fight, and when the extraction vehicle lands, order them to board it explicitly. The quest does not complete on its own.",
        "rationale": "run-002: the Hunted Knight (Antigonos Baspho) arrived at 18% mood, hit 14%, was downed once, and left only after being ordered into the shuttle; that order ended the quest in success.",
        "source": ["run-002-adv-cassandra.md", "player correction 2026-10-19"],
        "confidence": 0.7,
        "tags": ["quests", "guests", "escort", "mood"],
    },
    {
        "title": "Restrict a temporary pawn's allowed area on the day they arrive",
        "trigger": trig(phases=("stabilization", "expansion"), threats=("predator", "raid")),
        "recommendation": "Put quest guests, visitors and prisoners in an allowed area covering the base and freezer only. They wander to satisfy their own needs and get downed outside the defensive line, where rescuing them costs the colony a firefight.",
        "rationale": "run-002: the quest guest walked roughly 100 cells to a river and was downed by a manhunter rat; Matthew and Toni had to leave the base to recover him.",
        "source": ["run-002-adv-cassandra.md", "player correction 2026-10-19"],
        "confidence": 0.65,
        "tags": ["allowed_area", "guests", "safety"],
    },
    {
        "title": "Fire during a raid is usually enemy action, not a construction accident",
        "trigger": trig(phases=("raid_prep", "crisis"), threats=("raid", "fire")),
        "recommendation": "When fire starts during a raid, assume arson: name one firefighter, keep the rest on the fighting line, and treat the burning room as part of the battle. Do not wait for the raid to end before putting it out.",
        "rationale": "run-002: the 12th Aprimay fire coincided with the raiders and the player confirmed a raider lit it. Eight of the run's twelve urgent records came from that single fire-plus-raid incident.",
        "source": ["run-002-adv-cassandra.md", "player correction 2026-10-19"],
        "confidence": 0.6,
        "tags": ["fire", "raid", "combat"],
    },
]

for item in new:
    item.setdefault("times_applied", 0)
    item.setdefault("times_helped", 0)
    item.setdefault("times_failed", 0)
    item["status"] = "active"
    item["source_runs"] = ["run-002"]
    item["last_updated"] = "2026-10-19"
    item["id"] = f"L-{next_id:04d}"
    next_id += 1
    rows.append(item)

with open(path, "w", encoding="utf-8") as f:
    for r in rows:
        f.write(json.dumps(r, ensure_ascii=False) + "\n")

print("lessons now:", len(rows))
for r in rows[-4:]:
    print(r["id"], r["title"])
