import json, requests, time

URL="http://localhost:8787/"
def call(n,a=None):
    p={'jsonrpc':'2.0','id':1,'method':'tools/call','params':{'name':n,'arguments':a or {}}}
    r=requests.post(URL,json=p,timeout=15)
    d=r.json(); t=d['result']['content'][0]['text']
    try: return json.loads(t)
    except: return {'text':t}

ids=[]; off=0; total=0
while True:
    r=call('list_things',{'category':'item','limit':100,'offset':off})
    th=r.get('things',[])
    if not th: break
    total+=len(th)
    for t in th:
        if t.get('forbidden') is True:
            ids.append(t['id'])
    off+=len(th)
    if len(th)<100: break
    time.sleep(0.3)

print('total items:', total, 'forbidden:', len(ids))
# unforbid with small delay
done=0
for iid in ids:
    try:
        call('do_thing_action',{'id':iid,'label':'Allow'})
        done+=1
    except Exception as e:
        print('err', iid, e)
    time.sleep(0.2)
print('unforbidden:', done)
