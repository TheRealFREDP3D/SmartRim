import json, requests
URL="http://localhost:8787/"
def call(n,a=None):
    p={'jsonrpc':'2.0','id':1,'method':'tools/call','params':{'name':n,'arguments':a or {}}}
    r=requests.post(URL,json=p,timeout=30)
    d=r.json(); t=d['result']['content'][0]['text']
    try: return json.loads(t)
    except: return {'text':t}

# get colonist id
st=call('get_status')
cid=st['bundled']['list_colonists']['colonists'][0]['id']
print('colonist id', cid)
r=call('inspect_thing',{'id':cid})
print('actions:', [a.get('label') for a in r.get('actions',[])])
print('tabs:', r.get('tabs'))
print(json.dumps(r, indent=2)[:1500])
