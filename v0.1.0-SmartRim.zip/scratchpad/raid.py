import json, requests
URL="http://localhost:8787/"
def call(n,a=None):
    p={'jsonrpc':'2.0','id':1,'method':'tools/call','params':{'name':n,'arguments':a or {}}}
    r=requests.post(URL,json=p,timeout=30)
    d=r.json(); t=d['result']['content'][0]['text']
    try: return json.loads(t)
    except: return {'text':t}

st=call('get_status')
ids=','.join(c['id'] for c in st['bundled']['list_colonists']['colonists'])
print('draft:', call('draft',{'action':'draft','ids':ids}))
msg='RAID: Pollution Unit, 1 raider Swamp at (249,179). Drafted all 3. Waiting for them to approach. Stay at door.'
print(call('say',{'text':msg})['shown'])
