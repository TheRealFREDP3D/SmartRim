"""Attach quest context to a finished run's metadata, from text captured from the game."""
import json
import os
import sys

RUN_ID = sys.argv[1] if len(sys.argv) > 1 else "run-002-adv-cassandra"
META = os.path.join("memory", "runs", f"{RUN_ID}.meta.json")

QUESTS = [
    {"id": 0, "name": "Mechanoid Signal", "states": ["Ongoing"], "accepter": None,
     "description": "Signals from a mechanoid cluster were detected nearby. Not approached during this run."},
    {"id": 1, "name": "The Hunted Knight", "states": ["NotYetAccepted", "Ongoing", "EndedSuccess"],
     "accepter": "Matthew",
     "description": "Antigonos Baspho, a knight of The Shattered Empire, is calling from nearby. His guards "
                    "were killed in an ambush. He escaped, but is now being followed by a manhunting rat. "
                    "Antigonos wants you to keep him safe at Tesnus for a few hours until his shuttle can "
                    "come pick him up."},
    {"id": 2, "name": "Matthew's Novice Ceremony", "states": ["NotYetAccepted"], "accepter": None,
     "description": "The Shattered Empire is ready to grant Matthew the title of novice and a level 1 "
                    "psylink in a bestowing ceremony. The bestower will arrive by shuttle and perform the "
                    "ceremony."},
]

meta = {}
if os.path.exists(META):
    meta = json.load(open(META, encoding="utf-8"))
meta["quests"] = QUESTS
meta["quests_recorded_after_run"] = True
json.dump(meta, open(META, "w", encoding="utf-8"), indent=2)
print("written:", META)
print(json.dumps(meta, indent=2)[:600])
