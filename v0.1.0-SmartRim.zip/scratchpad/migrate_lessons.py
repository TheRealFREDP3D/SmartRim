import json, os
from datetime import date

BASE = r"C:\Users\fred\Desktop\RimWorld Consellor\RimAutonomous"
OUT = os.path.join(BASE, "memory", "lessons.jsonl")

# (id, title, trigger, recommendation, rationale, source, confidence, status, tags, source_runs, difficulty, storyteller)
lessons = [
 ("L-0001", "No herbal medicine at game start",
  {"phases": ["early_survival"], "threats": ["colonist_injured", "medical_untreated"], "resources": ["no_medicine"], "difficulty": [], "storyteller": [], "biome": []},
  "Harvest wild healroot on Day 1-2; plant healroot growing zone (Growing 8+); build drug lab for medicine crafting.",
  "Session 1: colonists died from injuries no one could treat (no medicine).",
  ["session-1.md", "wiki:Herbal_medicine", "wiki:Research"], 0.5, "active",
  ["medicine", "early_game"], ["session-1"], ["Adventure story"], ["Cassandra Classic"]),

 ("L-0002", "No medical bed early",
  {"phases": ["early_survival"], "threats": ["colonist_injured", "medical_untreated"], "resources": [], "difficulty": [], "storyteller": [], "biome": []},
  "Build 1-2 beds designated as medical early; assign doctor work type to best medicine pawn.",
  "Session 1 and 3: downed colonists could not heal without a medical bed.",
  ["session-1.md", "session-3.md"], 0.3, "active",
  ["medical", "early_game"], ["session-1", "session-3"], [], []),

 ("L-0003", "Ignoring animal threats",
  {"phases": ["early_survival"], "threats": ["predator_near_worker"], "resources": [], "difficulty": [], "storyteller": [], "biome": []},
  "Check wildlife tab for predators; draft colonists if dangerous animals near; build walls around growing zones and work areas. Do not hunt predators.",
  "Session 1: guinea pig killed Vlad. Session 2: timber wolf killed Shin while hunting.",
  ["session-1.md", "session-2.md", "wiki:Animals"], 0.5, "active",
  ["animals", "defense", "early_game"], ["session-1", "session-2"], [], []),

 ("L-0004", "Not burying corpses",
  {"phases": ["early_survival", "stabilization"], "threats": ["mood_break_risk"], "resources": [], "difficulty": [], "storyteller": [], "biome": []},
  "Designate dumping stockpile for corpses or butcher them; set hauling priority high for corpse removal.",
  "Unburied colonist corpse causes a 'left unburied' thought after 4 game days (wiki: Thoughts).",
  ["session-1.md", "session-2.md", "wiki:Thoughts"], 0.5, "active",
  ["mood", "corpses"], ["session-1", "session-2"], [], []),

 ("L-0005", "Mood spiral after lover death",
  {"phases": ["early_survival", "stabilization", "crisis"], "threats": ["mood_break_risk"], "resources": [], "difficulty": [], "storyteller": [], "biome": []},
  "Monitor colonist relationships; watch for grief debuffs; have recreation and food ready during crises.",
  "Session 1: Roni mental break after Vlad died; mood dropped to 14%.",
  ["session-1.md"], 0.3, "active",
  ["mood", "relationships"], ["session-1"], [], []),

 ("L-0006", "Hunter killed by predator",
  {"phases": ["early_survival", "stabilization"], "threats": ["predator_near_worker"], "resources": [], "difficulty": [], "storyteller": [], "biome": []},
  "Do not hunt predators. Check wildlife tab for predators near hunting ground. Never hunt alone at map edge. Draft a fighter escort.",
  "Session 2 Day 5: Shin mauled by timber wolf while hunting deer herd. Time advanced at Superfast hid the attack.",
  ["session-2.md", "wiki:Animals"], 0.5, "active",
  ["hunting", "animals", "defense"], ["session-2"], [], []),

 ("L-0007", "No freezer early",
  {"phases": ["early_survival"], "threats": ["low_food"], "resources": [], "difficulty": [], "storyteller": [], "biome": []},
  "Build 7x7 freezer room by Day 4-7, set cooler to -5C. Place near kitchen for short hauling routes.",
  "Session 2: food rotted, colonists ate raw food, mood crashed.",
  ["session-2.md", "wiki:Cooler"], 0.3, "active",
  ["food", "base_design", "early_game"], ["session-2"], [], []),

 ("L-0008", "Eating without table",
  {"phases": ["early_survival"], "threats": ["mood_break_risk"], "resources": [], "difficulty": [], "storyteller": [], "biome": []},
  "Place table + chairs in shelter on Day 1.",
  "Eating without a table gives a mood debuff.",
  ["beginner-guide.md", "wiki:Thoughts"], 0.3, "active",
  ["mood", "furniture", "early_game"], [], [], []),

 ("L-0009", "Sleeping outside or cold",
  {"phases": ["early_survival"], "threats": ["mood_break_risk"], "resources": [], "difficulty": [], "storyteller": [], "biome": []},
  "Build enclosed shelter with roof before nightfall.",
  "Multiple mood debuffs from sleeping outside or in cold.",
  ["beginner-guide.md"], 0.3, "active",
  ["mood", "shelter", "early_game"], [], [], []),

 ("L-0010", "No recreation variety",
  {"phases": ["early_survival", "stabilization"], "threats": ["mood_break_risk"], "resources": [], "difficulty": [], "storyteller": [], "biome": []},
  "Build horseshoe pin Day 1; add chess table and TV later. 2-6 recreation types needed depending on wealth expectations (wiki: Wealth).",
  "Mood stagnates without recreation variety. Tolerance builds with repetition (wiki: Recreation).",
  ["beginner-guide.md", "wiki:Recreation", "wiki:Wealth"], 0.5, "active",
  ["mood", "recreation"], [], [], []),

 ("L-0011", "Cooking in dirty area",
  {"phases": ["early_survival"], "threats": ["mood_break_risk", "colonist_injured"], "resources": [], "difficulty": [], "storyteller": [], "biome": []},
  "Separate kitchen from workshop; floor the kitchen. Cleanliness affects food poisoning chance (wiki: Blood_loss, Bedroom).",
  "Session 2: Peachy got food poisoning from dirty outdoor cooking area, mood crashed to 20%.",
  ["session-2.md", "wiki:Blood_loss", "wiki:Bedroom"], 0.5, "active",
  ["food", "kitchen", "cleanliness"], ["session-2"], [], []),

 ("L-0012", "Small stockpile jams colony",
  {"phases": ["early_survival"], "threats": ["idle_colonists"], "resources": [], "difficulty": [], "storyteller": [], "biome": []},
  "Make stockpiles large (49+ cells). Small zones fill to 100% and idle the whole colony.",
  "Session 2: 6-cell stockpile hit 100% full, entire colony went idle.",
  ["session-2.md"], 0.3, "active",
  ["stockpile", "logistics", "early_game"], ["session-2"], [], []),

 ("L-0013", "Time control: never bare-unpause",
  {"phases": ["early_survival", "stabilization", "raid_prep", "expansion", "crisis"], "threats": ["threat_response"], "resources": [], "difficulty": [], "storyteller": [], "biome": []},
  "Always use wait_for_event with maxGameHours + pause='always'. Bare unpause at Superfast hides events and kills colonists.",
  "Session 2: bare unpause at Superfast hid wolf kill + raid. Shin died. Session 3: sparrow attack unobserved.",
  ["session-2.md", "session-3.md", "AGENTS.md"], 0.5, "active",
  ["time_control", "safety"], ["session-2", "session-3"], [], []),

 ("L-0014", "Hunting at map edge solo",
  {"phases": ["early_survival", "stabilization"], "threats": ["predator_near_worker"], "resources": [], "difficulty": [], "storyteller": [], "biome": []},
  "Never hunt alone at map edge. Draft a fighter escort. Pause and watch when a hunt starts.",
  "Session 2: Shin mauled by timber wolf at far map edge, no one near to tend her.",
  ["session-2.md", "wiki:Animals"], 0.5, "active",
  ["hunting", "animals", "defense"], ["session-2"], [], []),

 ("L-0015", "Wildlife can break into base",
  {"phases": ["early_survival", "stabilization"], "threats": ["danger_high", "raid_incoming"], "resources": [], "difficulty": [], "storyteller": [], "biome": []},
  "Watch DangerRating and threat warnings. Wildlife can enter the base.",
  "Session 3: wild sparrow downed 2 colonists inside base. DangerRating High.",
  ["session-3.md"], 0.3, "active",
  ["defense", "animals", "early_game"], ["session-3"], [], []),

 ("L-0016", "Food runs low by Day 6-7",
  {"phases": ["early_survival"], "threats": ["low_food"], "resources": ["food_under_5_days"], "difficulty": [], "storyteller": [], "biome": []},
  "Plant 40-60 tiles of rice on Day 1. Cook simple meals steadily. Keep 2+ weeks of food.",
  "Session 4 and 5: low food alert by Day 8/Day 6. Rice harvest started late.",
  ["session-4.md", "session-5.md", "wiki:Rice", "wiki:Farming"], 0.5, "active",
  ["food", "early_game"], ["session-4", "session-5"], [], []),

 ("L-0017", "Construction not prioritized",
  {"phases": ["early_survival"], "threats": ["idle_colonists"], "resources": [], "difficulty": [], "storyteller": [], "biome": []},
  "Assign Construction priority 1 to a capable pawn early. Verify blueprints actually get built. Don't let walls stall.",
  "Session 4: 13 wall blueprints sat unbuilt for 3+ days. 'Need defenses' alert persisted Days 3-6.",
  ["session-4.md", "wiki:Construction"], 0.3, "active",
  ["construction", "defense", "early_game"], ["session-4"], [], []),

 ("L-0018", "Research bench placement",
  {"phases": ["early_survival"], "threats": ["idle_colonists"], "resources": [], "difficulty": [], "storyteller": [], "biome": []},
  "Place research bench indoors with light. Cleanliness affects research speed (wiki: Bedroom, Research).",
  "Session 3 and 4: 'Need research project' alert. Bench outside room airspace.",
  ["session-3.md", "session-4.md", "wiki:Bedroom", "wiki:Research"], 0.5, "active",
  ["research", "base_design", "early_game"], ["session-3", "session-4"], [], []),

 ("L-0019", "Medical treatment without medical bed",
  {"phases": ["early_survival", "stabilization"], "threats": ["medical_untreated", "colonist_injured"], "resources": [], "difficulty": [], "storyteller": [], "biome": []},
  "Set a bed to medical early. Keep doctor assigned and medicine stocked. Injuries happen even on easy.",
  "Session 4 Day 6: 'Medical treatment needed' despite 30 medicine. Session 5: Tyren wounded in raid, healed via medical bed.",
  ["session-4.md", "session-5.md"], 0.3, "active",
  ["medical", "early_game"], ["session-4", "session-5"], [], []),

 ("L-0020", "Shared barracks mood penalty",
  {"phases": ["early_survival", "stabilization"], "threats": ["mood_break_risk"], "resources": [], "difficulty": [], "storyteller": [], "biome": []},
  "Build individual bedrooms (3x3+) early. Dull barracks -5, awful barracks -7 mood (wiki: Thoughts, Bedroom).",
  "Session 5: moods 40-77 in shared barracks. Horseshoes pin helped +5-10.",
  ["session-5.md", "wiki:Thoughts", "wiki:Bedroom"], 0.5, "active",
  ["mood", "base_design", "housing"], ["session-5"], [], []),

 ("L-0021", "Social friction: Henry (misogynist) + Chaz (female)",
  {"phases": ["early_survival", "stabilization"], "threats": ["mood_break_risk"], "resources": [], "difficulty": [], "storyteller": [], "biome": []},
  "Monitor social traits. Misogynist pawns may cause friction with female colonists. Separate or manage.",
  "Session 5: Henry's mood 48-57, Chaz 51-68. Social friction observed.",
  ["session-5.md"], 0.3, "active",
  ["mood", "social", "traits"], ["session-5"], [], []),

 ("L-0022", "Sandbags need cloth or Fabric/Leathery",
  {"phases": ["early_survival", "raid_prep"], "threats": ["raid_incoming"], "resources": [], "difficulty": [], "storyteller": [], "biome": []},
  "Plant cotton on Day 1 for cloth. MCP tool only accepted cloth; wiki says Fabric or Leathery. Re-test other materials in-game.",
  "Session 5: 'Need defenses' alert persisted 7 days — no cloth for sandbags.",
  ["session-5.md", "wiki:Sandbags"], 0.3, "needs_review",
  ["defense", "materials", "early_game"], ["session-5"], [], []),

 ("L-0023", "Do not pack everything into one room",
  {"phases": ["early_survival"], "threats": [], "resources": [], "difficulty": [], "storyteller": [], "biome": []},
  "Separate room roles: bedroom (bed), dining (table+chairs), kitchen (stove), workshop (benches), hospital (medical beds), laboratory (research bench), rec room (horseshoes/TV). A room can serve multiple roles but mixing kitchen/workshop with living spaces causes problems.",
  "Session 6: packed everything into 7x7, research bench conflicts with bed interaction spots, 'Need research bench' alert.",
  ["session-6.md", "wiki:Room_roles", "wiki:Bedroom"], 0.5, "active",
  ["base_design", "rooms", "early_game"], ["session-6"], [], []),

 ("L-0024", "Tyren (psychopath) in melee",
  {"phases": ["early_survival", "stabilization"], "threats": ["colonist_injured"], "resources": [], "difficulty": [], "storyteller": [], "biome": []},
  "Keep fighters at range. Use melee only as last resort. Psychopaths don't get social mood boosts but still feel pain.",
  "Session 5: Tyren took knife wounds (80 HP) in close combat during raid.",
  ["session-5.md", "wiki:Animals"], 0.3, "active",
  ["combat", "defense", "traits"], ["session-5"], [], []),

 ("L-0025", "First raid can come early",
  {"phases": ["early_survival"], "threats": ["raid_incoming"], "resources": [], "difficulty": [], "storyteller": [], "biome": []},
  "Have weapons + sandbags ready by Day 5. First raid window is not fixed at Days 8-15 (Session 5 raid came Day 5 under Phoebe).",
  "Session 5: raid on Day 5 (Pollution Unit, 1 raider). 'Need defenses' alert persisted 7 days.",
  ["session-5.md"], 0.3, "needs_review",
  ["defense", "raid", "early_game"], ["session-5"], ["Community builder"], ["Phoebe Chillax"]),

 ("L-0026", "Research set to Smithing first",
  {"phases": ["early_survival"], "threats": [], "resources": [], "difficulty": [], "storyteller": [], "biome": []},
  "Smithing (700) is the gateway to weapons and armor. Set it on Day 1.",
  "Session 5: Smithing completed Day 5, set Batteries next.",
  ["session-5.md", "wiki:Research"], 0.5, "active",
  ["research", "early_game"], ["session-5"], [], []),

 ("L-0027", "Idle colonist needs secondary work",
  {"phases": ["early_survival", "stabilization"], "threats": ["idle_colonists"], "resources": [], "difficulty": [], "storyteller": [], "biome": []},
  "Give idle colonists secondary work (haul, clean, construct). Chaz idled when research bench occupied.",
  "Session 5: '1 colonist idle' alert. Chaz wandered when research bench was occupied.",
  ["session-5.md"], 0.3, "active",
  ["work_priorities", "early_game"], ["session-5"], [], []),

 ("L-0028", "Tyren (psychopath) mood management",
  {"phases": ["early_survival", "stabilization"], "threats": ["mood_break_risk"], "resources": [], "difficulty": [], "storyteller": [], "biome": []},
  "Psychopaths don't get social mood boosts. Use recreation (horseshoes) and good food to compensate. Mood 40-77 observed.",
  "Session 5: Tyren mood 40-77. Horseshoes pin helped. Medical bed set for healing.",
  ["session-5.md", "wiki:Mood"], 0.3, "active",
  ["mood", "traits", "early_game"], ["session-5"], [], []),

 ("L-0029", "Naming dialog (faction/settlement)",
  {"phases": ["early_survival"], "threats": [], "resources": [], "difficulty": [], "storyteller": [], "biome": []},
  "The naming dialog appears repeatedly. Close with window_action close or set text and accept.",
  "Session 5: Dialog_NamePlayerFactionAndSettlement appeared multiple times.",
  ["session-5.md"], 0.3, "active",
  ["ui", "game_quirks"], ["session-5"], [], []),

 ("L-0030", "Wait is already in progress",
  {"phases": ["early_survival", "stabilization", "raid_prep", "expansion", "crisis"], "threats": [], "resources": [], "difficulty": [], "storyteller": [], "biome": []},
  "wait_for_event can get stuck. Use real-time sleep (time.sleep) as fallback. Check game state after.",
  "Session 5 and 6: 'A wait is already in progress' error from stuck wait_for_event.",
  ["session-5.md", "session-6.md"], 0.3, "active",
  ["time_control", "game_quirks"], ["session-5", "session-6"], [], []),

 ("L-0031", "Research bench conflicts with bed placement",
  {"phases": ["early_survival"], "threats": [], "resources": [], "difficulty": [], "storyteller": [], "biome": []},
  "Research bench interaction spots conflict with bed placement. Plan interior layout carefully or place bench outside.",
  "Session 6: bench placed outside due to interaction spot conflict with beds.",
  ["session-6.md"], 0.3, "active",
  ["base_design", "research", "early_game"], ["session-6"], [], []),

 ("L-0032", "Cotton for cloth/sandbags",
  {"phases": ["early_survival", "raid_prep"], "threats": ["raid_incoming"], "resources": [], "difficulty": [], "storyteller": [], "biome": []},
  "Plant cotton early for cloth. Sandbags need cloth (MCP) or Fabric/Leathery (wiki).",
  "Session 5: 'Need defenses' alert persisted 7 days — no cloth for sandbags.",
  ["session-5.md", "wiki:Sandbags"], 0.3, "needs_review",
  ["defense", "materials", "early_game"], ["session-5"], [], []),

 ("L-0033", "Rice field sowing takes time",
  {"phases": ["early_survival"], "threats": ["low_food"], "resources": ["food_under_5_days"], "difficulty": [], "storyteller": [], "biome": []},
  "Start sowing rice on Day 1. 197-cell field took 5-6 days to sow. Harvest started Day 6.",
  "Session 5: rice harvest began Day 6. Low food alert Day 6-7.",
  ["session-5.md", "wiki:Rice", "wiki:Farming"], 0.3, "active",
  ["food", "farming", "early_game"], ["session-5"], [], []),

 ("L-0034", "Henry (misogynist) + Chaz (female) social friction",
  {"phases": ["early_survival", "stabilization"], "threats": ["mood_break_risk"], "resources": [], "difficulty": [], "storyteller": [], "biome": []},
  "Misogynist pawns cause social friction with female colonists. Monitor mood or separate.",
  "Session 5: Henry mood 48-57, Chaz 51-68. Social friction observed.",
  ["session-5.md"], 0.3, "active",
  ["mood", "social", "traits"], ["session-5"], [], []),

 ("L-0035", "Medical bed helps healing",
  {"phases": ["early_survival", "stabilization"], "threats": ["colonist_injured", "medical_untreated"], "resources": [], "difficulty": [], "storyteller": [], "biome": []},
  "Set a bed to medical early. Tyren healed from 80 to 100 HP using medical bed.",
  "Session 5: Tyren wounded in raid (80 HP), healed to 100 via medical bed.",
  ["session-5.md"], 0.3, "active",
  ["medical", "early_game"], ["session-5"], [], []),

 ("L-0036", "First raid can come early (Day 5)",
  {"phases": ["early_survival"], "threats": ["raid_incoming"], "resources": [], "difficulty": [], "storyteller": [], "biome": []},
  "Have weapons + defenses ready by Day 5. First raid window is not fixed at Days 8-15.",
  "Session 5: raid on Day 5 (Pollution Unit, 1 raider). 'Need defenses' alert persisted 7 days.",
  ["session-5.md"], 0.3, "needs_review",
  ["defense", "raid", "early_game"], ["session-5"], ["Community builder"], ["Phoebe Chillax"]),

 ("L-0037", "Tyren (psychopath) mood management",
  {"phases": ["early_survival", "stabilization"], "threats": ["mood_break_risk"], "resources": [], "difficulty": [], "storyteller": [], "biome": []},
  "Psychopaths don't get social mood boosts. Use recreation (horseshoes) and good food to compensate. Mood 40-77 observed.",
  "Session 5: Tyren mood 40-77. Horseshoes pin helped. Medical bed set for healing.",
  ["session-5.md", "wiki:Mood"], 0.3, "active",
  ["mood", "traits", "early_game"], ["session-5"], [], []),

 ("L-0038", "Naming dialog (faction/settlement)",
  {"phases": ["early_survival"], "threats": [], "resources": [], "difficulty": [], "storyteller": [], "biome": []},
  "The naming dialog appears repeatedly. Close with window_action close or set text and accept.",
  "Session 5: Dialog_NamePlayerFactionAndSettlement appeared multiple times.",
  ["session-5.md"], 0.3, "active",
  ["ui", "game_quirks"], ["session-5"], [], []),

]

today = date.today().isoformat()
with open(OUT, "w", encoding="utf-8") as f:
    for (lid, title, trigger, rec, rationale, source, conf, status, tags, runs, diff, st) in lessons:
        obj = {
            "id": lid,
            "title": title,
            "trigger": trigger,
            "recommendation": rec,
            "rationale": rationale,
            "source": source,
            "confidence": conf,
            "times_applied": 0,
            "times_helped": 0,
            "times_failed": 0,
            "status": status,
            "tags": tags,
            "source_runs": runs,
            "last_updated": today,
        }
        # Add scope fields to trigger
        obj["trigger"]["difficulty"] = diff
        obj["trigger"]["storyteller"] = st
        obj["trigger"]["biome"] = []
        f.write(json.dumps(obj) + "\n")

print(f"Wrote {len(lessons)} lessons to {OUT}")
