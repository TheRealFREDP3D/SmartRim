import json, requests
URL="http://localhost:8787/"
def call(n,a=None):
    p={'jsonrpc':'2.0','id':1,'method':'tools/call','params':{'name':n,'arguments':a or {}}}
    r=requests.post(URL,json=p,timeout=30)
    d=r.json(); t=d['result']['content'][0]['text']
    try: return json.loads(t)
    except: return {'text':t}

# Byte: rifle + flak vest + flak pants + flak helmet? (Byte has no caring, but can wear)
print('Byte gear:', call('manage_gear',{'name':"Dominic 'Byte' Byter",'weapon':'Gun_BoltActionRifle4917','apparel':'Apparel_FlakVest4921,Apparel_FlakPants4920,Apparel_AdvancedHelmet4922'}))
# Beka: melee brawler - knife + flak vest + flak pants
print('Beka gear:', call('manage_gear',{'name':'Beka Pham','weapon':'MeleeWeapon_Knife4919','apparel':'Apparel_FlakVest4921,Apparel_FlakPants4920'}))
# Tiger: revolver + flak vest? (only one vest) - give duster? 
print('Tiger gear:', call('manage_gear',{'name':"Ticer 'Tiger' Nelson",'weapon':'Gun_Revolver4918','apparel':'Apparel_Duster4924'}))
