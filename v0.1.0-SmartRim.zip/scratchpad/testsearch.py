import json, requests

URL = "http://localhost:8787/"


def call(n, a=None):
    p = {"jsonrpc": "2.0", "id": 1, "method": "tools/call", "params": {"name": n, "arguments": a or {}}}
    r = requests.post(URL, json=p, timeout=30)
    d = r.json()
    t = d["result"]["content"][0]["text"]
    try:
        return json.loads(t)
    except Exception:
        return {"text": t}


tests = [
    {"category": "item", "def": "MeleeWeapon_Knife", "limit": 5},
    {"category": "item", "defName": "MeleeWeapon_Knife", "limit": 5},
    {"category": "item", "search": "knife", "limit": 5},
    {"category": "item", "query": "knife", "limit": 5},
    {"category": "item", "filter": "knife", "limit": 5},
    {"category": "item", "label": "knife", "limit": 5},
]
for t in tests:
    r = call("list_things", t)
    things = r.get("things", []) if isinstance(r, dict) else []
    ids = [x.get("id") for x in things][:5]
    print(json.dumps(t), "-> matched=", r.get("matched"), "ids=", ids)
