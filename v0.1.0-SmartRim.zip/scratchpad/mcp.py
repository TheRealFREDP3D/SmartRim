"""Tiny MCP CLI for the run. Usage: python scratchpad/mcp.py <tool> ['{json args}']"""
import json
import sys

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.path.insert(0, "sidecar")
from mcp_client import McpClient
from config import MCP_URL, MCP_DELAY

tool = sys.argv[1]
args = json.loads(sys.argv[2]) if len(sys.argv) > 2 and sys.argv[2].strip() else {}
client = McpClient(MCP_URL, delay=MCP_DELAY)
result = client.call_tool(tool, args)
text = json.dumps(result, ensure_ascii=False)
print(text if len(text) <= 4000 else text[:4000] + f"... [{len(text)} chars]")
