import json, requests
URL="http://localhost:8787/"
def call(n,a=None):
    p={'jsonrpc':'2.0','id':1,'method':'tools/call','params':{'name':n,'arguments':a or {}}}
    r=requests.post(URL,json=p,timeout=30)
    d=r.json(); t=d['result']['content'][0]['text']
    try: return json.loads(t)
    except: return {'text':t}

print('pause:', call('set_speed',{'action':'pause'}))
for name in ["Dominic 'Byte' Byter", "Ticer 'Tiger' Nelson", "Beka Pham"]:
    print(name, call('set_work_priority',{'name':name,'workType':'PlantCutting','priority':1}))
# re-designate the tree
print('designate:', call('designate',{'designator':'Designator_PlantsHarvestWood','x':142,'z':143}))
