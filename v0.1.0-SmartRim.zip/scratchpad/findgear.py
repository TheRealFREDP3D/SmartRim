import json, requests

URL = "http://localhost:8787/"


def call(n, a=None):
    p = {"jsonrpc": "2.0", "id": 1, "method": "tools/call", "params": {"name": n, "arguments": a or {}}}
    r = requests.post(URL, json=p, timeout=30)
    d = r.json()
    t = d["result"]["content"][0]["text"]
    try:
        return json.loads(t)
    except Exception:
        return {"text": t}


DEFS = [
    "MeleeWeapon_Knife", "Gun_BoltActionRifle", "Gun_Revolver", "Gun_Pistol",
    "Gun_Autopistol", "Gun_SniperRifle", "Gun_Shotgun", "Gun_SMG", "Gun_AssaultRifle",
    "Apparel_FlakVest", "Apparel_FlakPants", "Apparel_FlakJacket", "Apparel_AdvancedHelmet",
    "Apparel_Duster", "Apparel_CollarShirt", "Apparel_Pants", "Apparel_Jacket",
    "MedicineIndustrial", "MedicineHerbal", "Silver", "ComponentIndustrial",
]

for d in DEFS:
    r = call("list_things", {"category": "item", "defName": d, "limit": 10})
    things = r.get("things", []) if isinstance(r, dict) else []
    if things:
        for t in things:
            print(d, "->", t.get("id"), "at", t.get("x"), t.get("z"), "count", t.get("stackCount"), "forbidden", t.get("forbidden"))
