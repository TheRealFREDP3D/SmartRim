import json, requests

def call(name, args=None):
    payload = {'jsonrpc':'2.0','id':1,'method':'tools/call','params':{'name':name,'arguments':args or {}}}
    resp = requests.post('http://localhost:8787/', json=payload, timeout=5)
    return json.loads(resp.json()['result']['content'][0]['text'])

for wt in ["Firefight", "Firefighting", "BedRest", "Basic"]:
    r = call('set_work_priority', {'name': 'Creed', 'workType': wt, 'priority': 1})
    print(f"{wt}: {json.dumps(r)}")
    print()
