import json, requests
URL="http://localhost:8787/"
def call(n,a=None):
    p={'jsonrpc':'2.0','id':1,'method':'tools/call','params':{'name':n,'arguments':a or {}}}
    r=requests.post(URL,json=p,timeout=30)
    d=r.json(); t=d['result']['content'][0]['text']
    try: return json.loads(t)
    except: return {'text':t}

for z in range(118,128):
    row=[]
    for x in range(130,140):
        r=call('inspect_thing',{'x':x,'z':z})
        lab=r.get('label') or ''
        if lab and lab not in ('grass','tall grass','ivy','bush','moss','dandelions') and 'Plant' not in lab and 'Chunk' not in lab and 'Steel' not in lab and 'Wood' not in lab:
            print(f'({x},{z}): {lab} {r.get("id")}')