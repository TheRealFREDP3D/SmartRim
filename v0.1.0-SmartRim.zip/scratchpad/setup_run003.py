"""Recreate the run-003 colony shell: scenario, storyteller, world, tile, ideoligion."""
import json
import sys
import time

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.path.insert(0, "sidecar")
from mcp_client import McpClient
from config import MCP_URL, MCP_DELAY

c = McpClient(MCP_URL, delay=MCP_DELAY)


def call(name, args=None):
    r = c.call_tool(name, args or {})
    print(f"  {name}: ok={r.get('ok')} stage={r.get('stage')} {str(r.get('error') or r.get('message') or '')[:90]}")
    return r


def wait_stage(target, timeout=180):
    t0 = time.time()
    while time.time() - t0 < timeout:
        r = c.call_tool("game_setup_status")
        if r.get("stage") == target:
            print(f"  reached stage={target}")
            return r
        time.sleep(4)
    raise SystemExit(f"timeout waiting for stage={target}")


print("new colony")
call("main_menu", {"action": "new_colony"})
call("select_scenario", {"name": "Crashlanded"})
call("select_storyteller", {"storyteller": "Cassandra", "difficulty": "Medium", "reloadAnytime": True})
call("select_storyteller", {"storyteller": "Cassandra", "difficulty": "Medium", "reloadAnytime": True})
call("create_world", {"seed": "counselor-003", "coverage": 0.5})
wait_stage("starting_site")
call("select_starting_site", {"tile": 34, "confirm": True})
call("choose_ideoligion", {"mode": "fluid"})
for _ in range(14):
    r = c.call_tool("edit_ideoligion", {"action": "next_step"})
    if not r.get("ok"):
        break
call("edit_ideoligion", {"action": "finalize"})
wait_stage("pawns")
print("done")
