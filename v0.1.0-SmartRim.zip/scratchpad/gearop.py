import json, requests
URL="http://localhost:8787/"
def call(n,a=None):
    p={'jsonrpc':'2.0','id':1,'method':'tools/call','params':{'name':n,'arguments':a or {}}}
    r=requests.post(URL,json=p,timeout=30)
    d=r.json(); t=d['result']['content'][0]['text']
    try: return json.loads(t)
    except: return {'text':t}

# Try various ops
for op in ['equip','drop','set','assign','wear']:
    r=call('manage_gear',{'name':"Dominic 'Byte' Byter",'op':op,'weapon':'Gun_BoltActionRifle4917'})
    print(op, '->', r.get('ok'), r.get('error'))
