"""Search the trade dialog UI text for silver figures."""
import json
import re
import sys

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.path.insert(0, "sidecar")
from mcp_client import McpClient
from config import MCP_URL, MCP_DELAY

c = McpClient(MCP_URL, delay=MCP_DELAY)
d = c.call_tool("get_window_ui", {"index": 1})
s = json.dumps(d, ensure_ascii=False)
print("len", len(s))
for key in ("labels", "texts", "rows", "buttons", "tabs"):
    v = d.get(key)
    if v:
        print("===", key, len(v))
for m in re.finditer(r"[^\"]{0,50}(ilver|300|216)[^\"]{0,50}", s):
    print("HIT:", m.group(0))
