import json, requests
URL="http://localhost:8787/"
def call(n,a=None):
    p={'jsonrpc':'2.0','id':1,'method':'tools/call','params':{'name':n,'arguments':a or {}}}
    r=requests.post(URL,json=p,timeout=30)
    d=r.json(); t=d['result']['content'][0]['text']
    try: return json.loads(t)
    except: return {'text':t}

# find ids
st=call('get_status')
ids={c['name']:c['id'] for c in st['bundled']['list_colonists']['colonists']}
print('ids', ids)

# draft Tyren and Henry
print('draft:', call('draft',{'action':'draft','ids':ids["Tyren Nordgren"]+','+ids["Henry 'Lawman' Jensen"]}))

# equip
print('Tyren knife:', call('manage_gear',{'name':'Tyren Nordgren','op':'equip','item':'MeleeWeapon_Knife4218'}))
print('Tyren vest:', call('manage_gear',{'name':'Tyren Nordgren','op':'wear','item':'Apparel_FlakVest4220'}))
print('Henry revolver:', call('manage_gear',{'name':"Henry 'Lawman' Jensen",'op':'equip','item':'Gun_Revolver4217'}))
print('Henry helmet:', call('manage_gear',{'name':"Henry 'Lawman' Jensen",'op':'wear','item':'Apparel_AdvancedHelmet4221'}))
