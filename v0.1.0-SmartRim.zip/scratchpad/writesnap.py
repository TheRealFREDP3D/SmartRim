import json, os, sys
sys.path.insert(0, r"C:\Users\fred\Desktop\RimWorld Consellor\RimAutonomous\sidecar")
from mcp_client import McpClient
from config import SNAPSHOTS_DIR
os.makedirs(SNAPSHOTS_DIR, exist_ok=True)
client = McpClient("http://localhost:8787/")
snapshot = {
    "day": "13th of Septober, 5500",
    "timestamp": __import__("datetime").datetime.now().isoformat(),
    "status": client.call_tool("get_status"),
    "conditions": client.call_tool("get_conditions"),
    "colonists": client.call_tool("list_colonists"),
    "resources": client.call_tool("get_resources"),
    "research": client.call_tool("get_research"),
    "alerts": client.call_tool("get_alerts"),
}
import monitor
monitor.normalize_snapshot(snapshot)
path = os.path.join(SNAPSHOTS_DIR, "day-13th of Septober, 5500.json")
with open(path, "w") as f:
    json.dump(snapshot, f, indent=2, default=str)
print("snapshot written:", path)
