import json, requests
URL="http://localhost:8787/"
def call(n,a=None):
    p={'jsonrpc':'2.0','id':1,'method':'tools/call','params':{'name':n,'arguments':a or {}}}
    r=requests.post(URL,json=p,timeout=10)
    d=r.json(); t=d['result']['content'][0]['text']
    try: return json.loads(t)
    except: return {'text':t}

BYTE="Dominic 'Byte' Byter"
BEKA="Beka Pham"
TIGER="Ticer 'Tiger' Nelson"

plans={
 BYTE: [('Firefighter',1),('Patient',1),('Research',1),('Construction',2),('Crafting',2),('Cooking',3),('Growing',3),('Mining',4),('Hauling',4),('Cleaning',4),('Hunting',4)],
 BEKA: [('Firefighter',1),('Patient',1),('Construction',1),('Hunting',2),('Hauling',2),('Cleaning',3),('Mining',3),('Growing',4),('Cooking',4),('Crafting',4)],
 TIGER:[('Firefighter',1),('Patient',1),('Doctor',1),('Growing',1),('Hunting',2),('Cooking',3),('Construction',3),('Hauling',4),('Cleaning',4),('Crafting',4),('Mining',4)],
}
for name, wts in plans.items():
    for wt,p in wts:
        r=call('set_work_priority',{'name':name,'workType':wt,'priority':p})
        print(name, wt, p, r.get('ok') if isinstance(r,dict) else r)
