"""Append run-002 lessons to memory/lessons.jsonl (source of truth) and re-render the markdown."""

import json
import os
import subprocess
import sys

PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "memory", "lessons.jsonl")

new = [
    {
        "id": "L-0039",
        "title": "Research-complete dialog silently stops time",
        "trigger": {"phases": ["any"], "threats": [], "resources": [], "difficulty": [], "storyteller": [], "biome": []},
        "recommendation": "When wait_for_event returns ticksWaited 0 and the hour never changes, call list_windows. A Dialog_NodeTree such as 'Research finished: ...' has forcePause true; close it with window_action(option=OK) before waiting again.",
        "rationale": "run-002: research completion dialogs stalled time for minutes; the monitor and the agent both saw 'no progress' until the dialog was closed.",
        "source": ["run-002-adv-cassandra.md"],
        "confidence": 0.6, "times_applied": 0, "times_helped": 0, "times_failed": 0,
        "status": "active", "tags": ["ui", "game_quirks", "wait_for_event"],
        "source_runs": ["run-002"], "last_updated": "2026-10-19",
    },
    {
        "id": "L-0040",
        "title": "Smithing is a separate work type from Crafting",
        "trigger": {"phases": ["early_survival", "raid_prep"], "threats": [], "resources": [], "difficulty": [], "storyteller": [], "biome": []},
        "recommendation": "To make weapons or smithy apparel, enable Smithing on a colonist (Crafting alone does nothing for the smithy). Smithing 1-2 is enough to get the bill started.",
        "rationale": "run-002: a longsword bill sat untouched for hours with a colonist at Crafting 1; setting Smithing 1 started it immediately.",
        "source": ["run-002-adv-cassandra.md"],
        "confidence": 0.6, "times_applied": 0, "times_helped": 0, "times_failed": 0,
        "status": "active", "tags": ["work_priorities", "crafting", "weapons"],
        "source_runs": ["run-002"], "last_updated": "2026-10-19",
    },
    {
        "id": "L-0041",
        "title": "Forever cook bills starve smithing and building",
        "trigger": {"phases": ["early_survival"], "threats": [], "resources": [], "difficulty": [], "storyteller": [], "biome": []},
        "recommendation": "Set cooking bills to a target count (10-12 meals) rather than 'forever', so the cook returns to other work when the stock is full.",
        "rationale": "run-002: a forever CookMealSimple bill kept Niklas at the stove for a whole day while the longsword bill had a colonist and 100 steel waiting.",
        "source": ["run-002-adv-cassandra.md"],
        "confidence": 0.6, "times_applied": 0, "times_helped": 0, "times_failed": 0,
        "status": "active", "tags": ["bills", "work_priorities", "food"],
        "source_runs": ["run-002"], "last_updated": "2026-10-19",
    },
    {
        "id": "L-0042",
        "title": "Ground food is invisible to get_resource_readout",
        "trigger": {"phases": ["early_survival"], "threats": ["food_low"], "resources": ["no_food"], "difficulty": [], "storyteller": [], "biome": []},
        "recommendation": "Before declaring a food emergency, count harvest on the ground with list_things (defName RawRice/RawBerries) and check that a stockpile has free cells and Hauling is enabled. The readout only counts stored items.",
        "rationale": "run-002: 34 rice stacks (~200 rice) sat in the field uncounted because the kitchen stockpile (5 cells) was full; the readout showed 24 rice and the colony looked starving.",
        "source": ["run-002-adv-cassandra.md"],
        "confidence": 0.6, "times_applied": 0, "times_helped": 0, "times_failed": 0,
        "status": "active", "tags": ["food", "hauling", "stockpiles"],
        "source_runs": ["run-002"], "last_updated": "2026-10-19",
    },
    {
        "id": "L-0043",
        "title": "New colonists need an allowed area",
        "trigger": {"phases": ["early_survival"], "threats": ["predator"], "resources": [], "difficulty": [], "storyteller": [], "biome": []},
        "recommendation": "After a quest colonist joins (or a wanderer), restrict them to the colony allowed area until they have a bed and a weapon. They wander far, get chased by predators and get downed.",
        "rationale": "run-002: the Hunted Knight's colonist walked to a river ~100 cells away, was chased by a manhunter rat, got downed at (249,51) and had to be saved by two drafted colonists.",
        "source": ["run-002-adv-cassandra.md"],
        "confidence": 0.5, "times_applied": 0, "times_helped": 0, "times_failed": 0,
        "status": "active", "tags": ["colonists", "quests", "safety"],
        "source_runs": ["run-002"], "last_updated": "2026-10-19",
    },
    {
        "id": "L-0044",
        "title": "Check recipe material costs before promising the item",
        "trigger": {"phases": ["raid_prep"], "threats": [], "resources": [], "difficulty": [], "storyteller": [], "biome": []},
        "recommendation": "Longsword needs 100 steel (not 50). Confirm stock or mine compacted steel (40 per tile) before adding the bill; the bill will sit idle saying 'Missing 100x metal or wood'.",
        "rationale": "run-002: 95 steel in stock blocked the longsword bill until 3 compacted steel tiles were mined next to the workshop.",
        "source": ["run-002-adv-cassandra.md"],
        "confidence": 0.6, "times_applied": 0, "times_helped": 0, "times_failed": 0,
        "status": "active", "tags": ["crafting", "weapons", "steel"],
        "source_runs": ["run-002"], "last_updated": "2026-10-19",
    },
]

existing = []
with open(PATH, encoding="utf-8") as f:
    for line in f:
        if line.strip():
            existing.append(json.loads(line))

ids = {r["id"] for r in existing}
added = [r for r in new if r["id"] not in ids]
existing.extend(added)

with open(PATH, "w", encoding="utf-8") as f:
    for r in existing:
        f.write(json.dumps(r, ensure_ascii=False) + "\n")

print(f"added {len(added)} lessons, total {len(existing)}")
subprocess.run([sys.executable, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "sidecar", "lessons.py"), "validate"], check=False)
subprocess.run([sys.executable, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "sidecar", "lessons.py"), "render"], check=False)
