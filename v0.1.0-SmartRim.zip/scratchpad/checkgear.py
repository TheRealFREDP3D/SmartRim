import json, requests
URL="http://localhost:8787/"
def call(n,a=None):
    p={'jsonrpc':'2.0','id':1,'method':'tools/call','params':{'name':n,'arguments':a or {}}}
    r=requests.post(URL,json=p,timeout=30)
    d=r.json(); t=d['result']['content'][0]['text']
    try: return json.loads(t)
    except: return {'text':t}

st=call('get_status')
for c in st['bundled']['list_colonists']['colonists']:
    g=call('get_pawn',{'id':c['id']})
    print(c['name'], 'weapon=', g.get('weapon'))
    print('  apparel=', g.get('apparel'))
