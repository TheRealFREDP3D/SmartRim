import json, os, re, time, urllib.request, urllib.parse

BASE = "https://rimworldwiki.com/wiki/"
CACHE = r"C:\Users\fred\Desktop\RimWorld Consellor\RimAutonomous\memory\wiki"
os.makedirs(CACHE, exist_ok=True)

PAGES = [
    "Main_Page",
    "Wealth",
    "Mood",
    "Research",
    "Medicine",
    "Herbal_medicine",
    "Cover",
    "Animals",
    "Stockpile",
    "Zones",
    "Temperature",
    "Electricity",
    "Raid",
    "Raid_points",
    "Mental_break",
    "Thoughts",
    "Traits",
    "Skills",
    "Health",
    "Food",
    "Nutrition",
    "Freezer",
    "Base_building",
    "Defense",
    "Turret",
    "Sandbags",
    "Growing",
    "Farming",
    "Hunting",
    "Smithing",
    "Batteries",
    "Solar_panel",
    "Wind_turbine",
    "Power",
    "Room",
    "Room_roles",
    "Impressiveness",
    "Beauty",
    "Lighting",
    "Prisoner",
    "Trade",
    "Caravan",
    "Quests",
    "Ideology_(DLC)",
    "Royalty_(DLC)",
    "Biotech_(DLC)",
    "Anomaly_(DLC)",
]

manifest = {}
manifest_path = os.path.join(CACHE, "manifest.json")
if os.path.exists(manifest_path):
    try:
        manifest = json.load(open(manifest_path))
    except Exception:
        manifest = {}

for slug in PAGES:
    url = BASE + slug
    out = os.path.join(CACHE, slug + ".md")
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "RimWorldCounselor/1.0"})
        with urllib.request.urlopen(req, timeout=30) as resp:
            html = resp.read().decode("utf-8", errors="replace")
        # crude: save raw HTML as .html, and also a text extraction
        with open(out.replace(".md", ".html"), "w", encoding="utf-8") as f:
            f.write(html)
        manifest[slug] = {"url": url, "fetched": time.strftime("%Y-%m-%d"), "size": len(html)}
        print("OK", slug, len(html))
    except Exception as e:
        print("FAIL", slug, str(e)[:80])
    time.sleep(0.5)

with open(manifest_path, "w", encoding="utf-8") as f:
    json.dump(manifest, f, indent=2)
print("manifest written:", len(manifest))
