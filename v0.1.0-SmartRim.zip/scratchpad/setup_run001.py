import json, requests
URL = "http://localhost:8787/"


def call(n, a=None):
    p = {"jsonrpc": "2.0", "id": 1, "method": "tools/call", "params": {"name": n, "arguments": a or {}}}
    r = requests.post(URL, json=p, timeout=30)
    d = r.json()
    t = d["result"]["content"][0]["text"]
    try:
        return json.loads(t)
    except Exception:
        return {"text": t}


MATTHEW = "Matthew Po"
CAMI = "Camilla 'Cami' Maney"
ANDY = "Andrew 'Andy' Camden"

r = call("list_unmanaged_items", {"limit": 500, "confirm": True})
gear = {}
for t in r.get("items", []):
    if t["def"] in ("Gun_BoltActionRifle", "Gun_Revolver", "MeleeWeapon_Knife", "Apparel_FlakVest",
                    "Apparel_FlakPants", "Apparel_AdvancedHelmet", "Apparel_Duster"):
        gear[t["def"]] = t["id"]
print("gear found:", gear)

print("Matthew rifle:", call("manage_gear", {"name": MATTHEW, "op": "equip", "item": gear.get("Gun_BoltActionRifle", "")}).get("ok"))
print("Cami knife:", call("manage_gear", {"name": CAMI, "op": "equip", "item": gear.get("MeleeWeapon_Knife", "")}).get("ok"))
print("Andy revolver:", call("manage_gear", {"name": ANDY, "op": "equip", "item": gear.get("Gun_Revolver", "")}).get("ok"))
print("Cami vest:", call("manage_gear", {"name": CAMI, "op": "wear", "item": gear.get("Apparel_FlakVest", "")}).get("ok"))
print("Andy helmet:", call("manage_gear", {"name": ANDY, "op": "wear", "item": gear.get("Apparel_AdvancedHelmet", "")}).get("ok"))
print("Cami pants:", call("manage_gear", {"name": CAMI, "op": "wear", "item": gear.get("Apparel_FlakPants", "")}).get("ok"))
print("Matthew duster:", call("manage_gear", {"name": MATTHEW, "op": "wear", "item": gear.get("Apparel_Duster", "")}).get("ok"))
print("research:", call("set_research", {"project": "Smithing"}).get("label"))
