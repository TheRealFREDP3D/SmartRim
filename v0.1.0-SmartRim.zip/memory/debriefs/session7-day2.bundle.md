# Debrief bundle: session7-day2

Generated: 2026-10-19T18:52:40. Paste this whole file into a chat model, then paste its answer into `session7-day2.response.md`.

## 1. Instructions

You are reviewing one RimWorld colony run to extract candidate lessons for a knowledge base.

Rules:
1. The wiki facts below are the source of truth. If a claim contradicts them, say so.
2. Cite evidence by in-game day (for example "Day 6, 12th of Septober") and by advice id.
3. Do not invent game mechanics. If you are unsure, list the claim under unverified_claims.
4. Do not repeat the timeline. Analyse it.
5. Propose at most 6 candidate lessons. Prefer fewer, better-supported ones.
6. Each candidate needs a trigger (phases, threats, resources, difficulty, storyteller, biome). Use "any" for unscoped fields.
7. Output exactly the two sections below, in this order, and nothing else.

Section A: a JSON array of candidate lessons. Each object has exactly these keys:
  title, cause_chain (array of short strings), trigger (object with phases, threats, resources, difficulty, storyteller, biome), recommendation, rationale, source (array of day strings or wiki page names), wiki_pages_used (array), unverified_claims (array), confidence (number 0.3 to 0.7).

Section B: a short markdown summary (max 10 bullet points): primary cause of failure or current risk, what worked, and what the next colony should do differently.

Phases (our own labels, not wiki terms): early_survival (day 0-7), stabilization (day 8-20), raid_prep, expansion, crisis.

## 2. Run metadata

- run_id: session7-day2
- difficulty: Adventure story (baseline)
- storyteller: Cassandra Classic (baseline)
- biome: unknown
- outcome: not stated by the user
- snapshots used: 5
- snapshots skipped (no colony data): day-13th of Septober, 5500.json

## 3. Wiki facts (source of truth, verified)

- Mental break base thresholds for a normal colonist: minor 35%, major 20%, extreme 5% (wiki:Mental_break). Traits shift them (wiki:Mental_break).
- Base mood by difficulty: Peaceful 42, Community builder 42, Adventure story 37, Strive to survive 32, Blood and dust 27, Losing is Fun 22 (wiki:Mood).
- Mood bar moves toward its target at most +12/hour up and -8/hour down (wiki:Mood).
- Raid points cap at 10,000; wealth points use storyteller wealth up to 1,000,000 (wiki:Raid_points, wiki:Wealth).
- Shared barracks: Dull barracks -5 and Awful barracks -7 mood versus a private bedroom (wiki:Thoughts, wiki:Bedroom).
- Raw food: flat 2% food poisoning; cooked meals depend on cook skill and kitchen cleanliness (wiki:Rice, wiki:Blood_loss).
- Freezing point 0 C prevents spoilage; coolers can make freezers (wiki:Cooler).
- Rice matures in about 5.54 days and yields 6 units per plant (wiki:Rice).
- Herbal medicine is extracted from healroot. Industrial medicine needs cloth 3 + herbal 1 + neutroamine 1 and Medicine production research (wiki:Herbal_medicine, wiki:Research).
- Drug production (drug lab) and Medicine production are separate research projects; Medicine production requires Drug production (wiki:Research).
- Predators hunt colonists when hungry and keep attacking downed prey (wiki:Animals). Guinea pigs are herbivores (wiki:Guinea_pig).
- Sandbags: 55% cover, built from Fabric or Leathery material, 5 units (wiki:Sandbags).
- Incapable of Violent: cannot equip weapons or hunt (wiki:Incapable).
- Unburied colonist corpse triggers a 'left unburied' thought after 4 game days (wiki:Thoughts).
- Difficulty: Community builder research speed 120%, threat scale 30%; Adventure story research 100%, threat scale 60% (wiki:Difficulty, wiki:AI_Storytellers).

## 4. Claims that are NOT verified (do not treat as facts)

- First raid day window (e.g. 'Days 8-15'): NOT in the wiki. Session 5 had a raid on Day 5 under Phoebe.
- Corpse -10 mood per corpse: NOT confirmed in the wiki text.
- Community Builder pre-researched projects: NOT in the wiki.
- Healroot 60% potency, packaged meal duration (~8 days for 3 pawns), ate-without-table -3: NOT confirmed.
- Sandbag material 'cloth only' (MCP tool observation): conflicts with the wiki (Fabric or Leathery).

## 5. Colony timeline

### 2nd of Aprimay, 5500 (hour 18)
- Bran 'Sawyher' Shawb: HP 100%, mood 71%, job: cutting dandelions.
- Taten 'Tater' Stamm: HP 100%, mood 69%, job: wandering.
- Baran Gargatosh: HP 100%, mood 73%, job: cutting grass.
- Alerts: Need colonist beds; Pen needed; 1 colonist idle
- Resources: silver 500, steel 150, component 30

### 8th of Aprimay, 5500 (hour 0)
- Andrew 'Andy' Camden: HP 100%, mood 61%, job: sleeping.
- Matthew Po: HP 100%, mood 63%, job: sleeping.
- Camilla 'Cami' Maney: HP 100%, mood 58%, job: sleeping.
- Alerts: Need research bench
- Resources: steel 885, silver 800, packaged survival meal 49, medicine 32, component 30, penoxycyline 8

### 9th of Aprimay, 5500 (hour 0)
- Andrew 'Andy' Camden: HP 100%, mood 51%, job: sleeping.
- Matthew Po: HP 100%, mood 48%, job: sleeping.
- Camilla 'Cami' Maney: HP 100%, mood 63%, job: sleeping.
- Resources: steel 1050, silver 800, packaged survival meal 42, medicine 32, component 30, penoxycyline 8

### 10th of Aprimay, 5500 (hour 17)
- Andrew 'Andy' Camden: HP 100%, mood 52%, job: consuming packaged survival meal.
- Matthew Po: HP 100%, mood 56%, job: researching.
- Camilla 'Cami' Maney: HP 100%, mood 58%, job: deconstructing wooden bed (<color=#FF0000>awful</color>).
- Alerts: Need defenses
- Resources: steel 908, silver 591, medicine 32, component 30, packaged survival meal 30, penoxycyline 8

### 10th of Aprimay, 5500 (hour 0)
- Andrew 'Andy' Camden: HP 100%, mood 44%, job: sleeping.
- Matthew Po: HP 100%, mood 57%, job: resting.
- Camilla 'Cami' Maney: HP 100%, mood 58%, job: sleeping.
- Alerts: Need defenses; Trader
- Resources: steel 1050, silver 591, packaged survival meal 34, medicine 32, component 30, penoxycyline 8

## 6. Advice log

(no advice records for this run)

## 7. Task

Produce Section A (JSON array) and Section B (markdown summary) as described in the instructions.
