# Debrief bundle: run-002-adv-cassandra

Generated: 2026-10-19T23:01:49. Paste this whole file into a chat model, then paste its answer into `run-002-adv-cassandra.response.md`.

## 1. Instructions

You are reviewing one RimWorld colony run to extract candidate lessons for a knowledge base.

Rules:
1. The wiki facts below are the source of truth. If a claim contradicts them, say so.
2. Cite evidence by in-game day (for example "Day 6, 12th of Septober") and by advice id.
3. Do not invent game mechanics. If you are unsure, list the claim under unverified_claims.
4. Read the quest context before calling a pawn a colonist. A quest target has an objective and a leaving condition, and treating them as a settler produces the wrong lesson.
5. Where a record carries "cause (recorded after the run)", that is ground truth from the player. Do not re-diagnose against it; build the lesson on it.
6. Do not repeat the timeline. Analyse it.
7. Propose at most 6 candidate lessons. Prefer fewer, better-supported ones.
8. Each candidate needs a trigger (phases, threats, resources, difficulty, storyteller, biome). Use "any" for unscoped fields.
9. Output exactly the two sections below, in this order, and nothing else.

Section A: a JSON array of candidate lessons. Each object has exactly these keys:
  title, cause_chain (array of short strings), trigger (object with phases, threats, resources, difficulty, storyteller, biome), recommendation, rationale, source (array of day strings or wiki page names), wiki_pages_used (array), unverified_claims (array), confidence (number 0.3 to 0.7).

Section B: a short markdown summary (max 10 bullet points): primary cause of failure or current risk, what worked, and what the next colony should do differently.

Phases (our own labels, not wiki terms): early_survival (day 0-7), stabilization (day 8-20), raid_prep, expansion, crisis.

## 2. Run metadata

- run_id: run-002-adv-cassandra
- bundle version: v3 (quests, event causes, incident snapshots)
- difficulty: Adventure story (baseline)
- storyteller: Cassandra Classic (baseline)
- biome: temperate forest (flat, tile 17, 13.4 C at landing)
- outcome: survived the full run (11 days, run-limited); 3 colonist(s) alive at the end, none downed; lowest end-of-day mood 51%; 13.8 days of food; 34 medicine; wealth 27294; urgent alerts 12, auto-pauses 12
- snapshots used: 12

Quest context from the game (colour tags removed; this is where quest objectives live):
(recorded after the run; this run's snapshots predate quest capture)

- quests seen this run:
  - [0] Mechanoid Signal - Ongoing
    Signals from a mechanoid cluster were detected nearby. Not approached during this run.
  - [1] The Hunted Knight - NotYetAccepted -> Ongoing -> EndedSuccess - accepted by Matthew
    Antigonos Baspho, a knight of The Shattered Empire, is calling from nearby. His guards were killed in an ambush. He escaped, but is now being followed by a manhunting rat. Antigonos wants you to keep him safe at Tesnus for a few hours until his shuttle can come pick him up.
  - [2] Matthew's Novice Ceremony - NotYetAccepted
    The Shattered Empire is ready to grant Matthew the title of novice and a level 1 psylink in a bestowing ceremony. The bestower will arrive by shuttle and perform the ceremony.

## 3. Wiki facts (source of truth, verified)

- Mental break base thresholds for a normal colonist: minor 35%, major 20%, extreme 5% (wiki:Mental_break). Traits shift them (wiki:Mental_break).
- Base mood by difficulty: Peaceful 42, Community builder 42, Adventure story 37, Strive to survive 32, Blood and dust 27, Losing is Fun 22 (wiki:Mood).
- Mood bar moves toward its target at most +12/hour up and -8/hour down (wiki:Mood).
- Raid points cap at 10,000; wealth points use storyteller wealth up to 1,000,000 (wiki:Raid_points, wiki:Wealth).
- Shared barracks: Dull barracks -5 and Awful barracks -7 mood versus a private bedroom (wiki:Thoughts, wiki:Bedroom).
- Raw food: flat 2% food poisoning; cooked meals depend on cook skill and kitchen cleanliness (wiki:Rice, wiki:Blood_loss).
- Freezing point 0 C prevents spoilage; coolers can make freezers (wiki:Cooler).
- Rice matures in about 5.54 days and yields 6 units per plant (wiki:Rice).
- Herbal medicine is extracted from healroot. Industrial medicine needs cloth 3 + herbal 1 + neutroamine 1 and Medicine production research (wiki:Herbal_medicine, wiki:Research).
- Drug production (drug lab) and Medicine production are separate research projects; Medicine production requires Drug production (wiki:Research).
- Predators hunt colonists when hungry and keep attacking downed prey (wiki:Animals). Guinea pigs are herbivores (wiki:Guinea_pig).
- Sandbags: 55% cover, built from Fabric or Leathery material, 5 units (wiki:Sandbags).
- Incapable of Violent: cannot equip weapons or hunt (wiki:Incapable).
- Unburied colonist corpse triggers a 'left unburied' thought after 4 game days (wiki:Thoughts).
- Difficulty: Community builder research speed 120%, threat scale 30%; Adventure story research 100%, threat scale 60% (wiki:Difficulty, wiki:AI_Storytellers).

## 4. Claims that are NOT verified (do not treat as facts)

- First raid day window (e.g. 'Days 8-15'): NOT in the wiki. Session 5 had a raid on Day 5 under Phoebe.
- Corpse -10 mood per corpse: NOT confirmed in the wiki text.
- Community Builder pre-researched projects: NOT in the wiki.
- Healroot 60% potency, packaged meal duration (~8 days for 3 pawns), ate-without-table -3: NOT confirmed.
- Sandbag material 'cloth only' (MCP tool observation): conflicts with the wiki (Fabric or Leathery).

## 5. Colony timeline

### 8th of Aprimay, 5500 (hour 1)
- Matthew Po: HP 100%, mood 63%, job: sleeping.
- Antonino 'Toni' Cefalu: HP 100%, mood 91%, job: sleeping.
- Niklas Fischer: HP 100%, mood 62%, job: sleeping.
- Alerts: Need colonist beds; Colonist can gain expertise; Need research bench

### 9th of Aprimay, 5500 (hour 1)
- Matthew Po: HP 100%, mood 49%, job: sleeping.
- Antonino 'Toni' Cefalu: HP 100%, mood 81%, job: sleeping.
- Niklas Fischer: HP 100%, mood 56%, job: sleeping.
- Alerts: Colonist can gain expertise
- Resources: silver 800, wood 599, steel 195, packaged survival meal 33, medicine 30, component 30

### 10th of Aprimay, 5500 (hour 1)
- Matthew Po: HP 100%, mood 43%, job: sleeping.
- Antonino 'Toni' Cefalu: HP 100%, mood 75%, job: sleeping.
- Niklas Fischer: HP 100%, mood 53%, job: sleeping.
- Alerts: Need defenses; Trader
- Resources: wood 814, silver 800, steel 195, medicine 30, component 30, packaged survival meal 26

### 11th of Aprimay, 5500 (hour 0)
- Matthew Po: HP 100%, mood 47%, job: sleeping.
- Antonino 'Toni' Cefalu: HP 100%, mood 60%, job: watching for targets.
- Niklas Fischer: HP 100%, mood 48%, job: sleeping.
- Resources: silver 800, wood 284, steel 195, medicine 30, component 30, packaged survival meal 19, herbal medicine 1

### 12th of Aprimay, 5500 (hour 0)
- Matthew Po: HP 100%, mood 64%, job: sleeping.
- Antonino 'Toni' Cefalu: HP 100%, mood 82%, job: sleeping.
- Niklas Fischer: HP 100%, mood 65%, job: sleeping.
- Alerts: Low food; Need research project
- Resources: silver 800, wood 215, steel 195, medicine 30, component 30, packaged survival meal 12, herbal medicine 4

### 13th of Aprimay, 5500 (hour 0)
- Matthew Po: HP 100%, mood 56%, job: researching.
- Antonino 'Toni' Cefalu: HP 83%, mood 62%, job: sleeping.
- Niklas Fischer: HP 100%, mood 66%, job: sleeping.
- Alerts: Low food; Medical treatment needed
- Resources: silver 800, steel 120, wood 89, medicine 30, component 30, rice 24, herbal medicine 7, packaged survival meal 5

### 14th of Aprimay, 5500 (hour 0)
- Matthew Po: HP 100%, mood 64%, job: sleeping.
- Antonino 'Toni' Cefalu: HP 100%, mood 83%, job: gathering berries to hauling inventory.
- Niklas Fischer: HP 100%, mood 72%, job: sleeping.
- Alerts: Low food
- Resources: silver 800, steel 95, wood 89, component 30, medicine 29, rice 24, herbal medicine 7, packaged survival meal 2

### 15th of Aprimay, 5500 (hour 0)
- Matthew Po: HP 100%, mood 61%, job: sleeping.
- Antonino 'Toni' Cefalu: HP 100%, mood 87%, job: sleeping.
- Niklas Fischer: HP 100%, mood 49%, job: sleeping.
- Resources: silver 800, rice 216, wood 105, steel 95, component 30, medicine 29, simple meal 10, herbal medicine 7, bird meat 4, wake-up 1

### 1st of Jugust, 5500 (hour 0)
- Matthew Po: HP 100%, mood 54%, job: sleeping.
- Antonino 'Toni' Cefalu: HP 100%, mood 63%, job: digging at compacted steel (25%).
- Niklas Fischer: HP 100%, mood 71%, job: Making longsword.
- Resources: silver 800, rice 174, wood 68, steel 59, component 30, medicine 29, simple meal 10, herbal medicine 7, wake-up 1

### 2nd of Jugust, 5500 (hour 0)
- Matthew Po: HP 100%, mood 50%, job: sleeping.
- Antonino 'Toni' Cefalu: HP 100%, mood 81%, job: sleeping.
- Niklas Fischer: HP 100%, mood 63%, job: relaxing socially.
- Antigonos Baspho: HP 100%, mood 18%, job: resting.
- Alerts: Need meditation spot; No acceptable food; Combatant unarmed; Low food; Major break risk
- Resources: silver 800, rice 104, steel 87, component 30, medicine 27, simple meal 10, wood 8, herbal medicine 7, wake-up 1

### 3rd of Jugust, 5500 (hour 1)
- Matthew Po: HP 100%, mood 57%, job: sleeping.
- Antonino 'Toni' Cefalu: HP 100%, mood 67%, job: sleeping.
- Niklas Fischer: HP 100%, mood 51%, job: sleeping.
- Alerts: Rector role unfilled
- Resources: silver 800, rice 64, steel 47, component 30, medicine 27, simple meal 11, hedgehog meat 9, wood 8, herbal medicine 7, wake-up 1

### 3rd of Jugust, 5500 (hour 6)
- Matthew Po: HP 100%, mood 57%, job: sleeping.
- Antonino 'Toni' Cefalu: HP 100%, mood 75%, job: refueling torch lamp.
- Niklas Fischer: HP 100%, mood 51%, job: sleeping.
- Alerts: Rector role unfilled
- Resources: silver 800, rice 64, steel 47, component 30, medicine 27, simple meal 10, hedgehog meat 9, wood 8, herbal medicine 7, wake-up 1

## 6. Notable changes and incidents (event digest)

Transitions between snapshots:

- 8th of Aprimay, 5500, hour 1: new alerts: Colonist can gain expertise; Need colonist beds; Need research bench
- 10th of Aprimay, 5500, hour 1: new alerts: Need defenses; Trader
- 12th of Aprimay, 5500, hour 0: new alerts: Low food; Need research project
- 13th of Aprimay, 5500, hour 0: new alerts: Medical treatment needed
- 13th of Aprimay, 5500, hour 0: Antonino 'Toni' Cefalu health 100% -> 83% (injury)
- 15th of Aprimay, 5500, hour 0: food stock jumped 26 -> 230 units
- 2nd of Jugust, 5500, hour 0: new alerts: Combatant unarmed; Low food; Major break risk; Need meditation spot; No acceptable food
- 3rd of Jugust, 5500, hour 1: new alerts: Rector role unfilled

(no incident snapshots for this run - they are captured only when an urgent alert fires)

Urgent advice recorded (in-game day from the monitor, real timestamp in section 7):

- 12th of Aprimay, 5500: Fire! (3x) [expired] - cause: raider arson during the raid
- 12th of Aprimay, 5500: Fire!; Hostile pawn nearby: Crusher, Captain at (192,119) (near colonist) [expired] - cause: raider arson during the raid
- 12th of Aprimay, 5500: Fire!; Enemy downed (2x) [expired] - cause: raider downed by colonists during the fire
- 12th of Aprimay, 5500: Fire!; Enemy downed; Hostile pawn nearby: Crusher, Captain at (192,119) (near colonist) [expired] - cause: raider downed by colonists during the fire
- 12th of Aprimay, 5500: Fire! [expired] - cause: raider arson during the raid
- 1st of Jugust, 5500: Antigonos Baspho is DOWNED [expired] - cause: protection-quest target, downed away from base before extraction
- 1st of Jugust, 5500: Antigonos Baspho mood at 18% (major break risk) [failed] - cause: quest target at 18% on arrival; not enough time to fix four unmet needs
- 2nd of Jugust, 5500: Antigonos Baspho mood at 18% (major break risk) [helped] - cause: quest target at 18% on arrival; not enough time to fix four unmet needs
- 2nd of Jugust, 5500: Antigonos Baspho mood at 14% (major break risk) [helped] - cause: quest target mood fell 18% -> 14% while needs were being fixed

## 7. Advice log

- adv-20261019-195839-17a911 | day=8th of Aprimay, 5500 | 2026-10-19T19:58:39.166161 | trigger=scheduled | severity=info | status=expired | auto_paused=False
  situation: Daily assessment for 8th of Aprimay, 5500
- adv-20261019-200657-840ec1 | day=9th of Aprimay, 5500 | 2026-10-19T20:06:57.583998 | trigger=scheduled | severity=info | status=expired | auto_paused=False
  situation: Daily assessment for 9th of Aprimay, 5500
- adv-20261019-201617-3a651d | day=10th of Aprimay, 5500 | 2026-10-19T20:16:17.548423 | trigger=scheduled | severity=info | status=expired | auto_paused=False
  situation: Daily assessment for 10th of Aprimay, 5500
- adv-20261019-202710-fdd215 | day=11th of Aprimay, 5500 | 2026-10-19T20:27:10.558408 | trigger=scheduled | severity=info | status=expired | auto_paused=False
  situation: Daily assessment for 11th of Aprimay, 5500
- adv-20261019-204008-adafba | day=12th of Aprimay, 5500 | 2026-10-19T20:40:08.561511 | trigger=scheduled | severity=info | status=expired | auto_paused=False
  situation: Daily assessment for 12th of Aprimay, 5500
- adv-20261019-204826-224135 | day=12th of Aprimay, 5500 | 2026-10-19T20:48:26.714606 | trigger=reflex | severity=urgent | status=expired | auto_paused=True
  situation: Fire!
  cause (recorded after the run): raider arson during the raid
- adv-20261019-204858-c03846 | day=12th of Aprimay, 5500 | 2026-10-19T20:48:58.528263 | trigger=reflex | severity=urgent | status=expired | auto_paused=True
  situation: Fire!
  cause (recorded after the run): raider arson during the raid
- adv-20261019-204930-bf6c6f | day=12th of Aprimay, 5500 | 2026-10-19T20:49:30.064707 | trigger=reflex | severity=urgent | status=expired | auto_paused=True
  situation: Fire!
  cause (recorded after the run): raider arson during the raid
- adv-20261019-205032-0eb9eb | day=12th of Aprimay, 5500 | 2026-10-19T20:50:32.793673 | trigger=reflex | severity=urgent | status=expired | auto_paused=True
  situation: Fire!; Hostile pawn nearby: Crusher<color=#999999FF>, Captain</color> at (192,119) (near colonist)
  cause (recorded after the run): raider arson during the raid
- adv-20261019-205104-178340 | day=12th of Aprimay, 5500 | 2026-10-19T20:51:04.321447 | trigger=reflex | severity=urgent | status=expired | auto_paused=True
  situation: Fire!; Enemy downed
  cause (recorded after the run): raider downed by colonists during the fire
- adv-20261019-205135-e9e0e2 | day=12th of Aprimay, 5500 | 2026-10-19T20:51:35.888598 | trigger=reflex | severity=urgent | status=expired | auto_paused=True
  situation: Fire!; Enemy downed
  cause (recorded after the run): raider downed by colonists during the fire
- adv-20261019-205207-1e1952 | day=12th of Aprimay, 5500 | 2026-10-19T20:52:07.755977 | trigger=reflex | severity=urgent | status=expired | auto_paused=True
  situation: Fire!; Enemy downed; Hostile pawn nearby: Crusher<color=#999999FF>, Captain</color> at (192,119) (near colonist)
  cause (recorded after the run): raider downed by colonists during the fire
- adv-20261019-205239-685533 | day=12th of Aprimay, 5500 | 2026-10-19T20:52:39.269277 | trigger=reflex | severity=urgent | status=expired | auto_paused=True
  situation: Fire!
  cause (recorded after the run): raider arson during the raid
- adv-20261019-205822-cb067b | day=13th of Aprimay, 5500 | 2026-10-19T20:58:22.316195 | trigger=scheduled | severity=info | status=expired | auto_paused=False
  situation: Daily assessment for 13th of Aprimay, 5500
- adv-20261019-210813-bd5487 | day=14th of Aprimay, 5500 | 2026-10-19T21:08:13.180739 | trigger=scheduled | severity=info | status=expired | auto_paused=False
  situation: Daily assessment for 14th of Aprimay, 5500
- adv-20261019-211835-41ffb4 | day=15th of Aprimay, 5500 | 2026-10-19T21:18:35.499324 | trigger=scheduled | severity=info | status=expired | auto_paused=False
  situation: Daily assessment for 15th of Aprimay, 5500
- adv-20261019-212728-246e70 | day=1st of Jugust, 5500 | 2026-10-19T21:27:28.207018 | trigger=scheduled | severity=info | status=expired | auto_paused=False
  situation: Daily assessment for 1st of Jugust, 5500
- adv-20261019-213208-8dfe88 | day=1st of Jugust, 5500 | 2026-10-19T21:32:08.643910 | trigger=reflex | severity=urgent | status=expired | auto_paused=True
  situation: Antigonos Baspho is DOWNED
  cause (recorded after the run): protection-quest target, downed away from base before extraction
- adv-20261019-213854-0c5f09 | day=1st of Jugust, 5500 | 2026-10-19T21:38:54.866832 | trigger=reflex | severity=urgent | status=failed | auto_paused=True
  situation: Antigonos Baspho mood at 18% (major break risk)
  cause (recorded after the run): quest target at 18% on arrival; not enough time to fix four unmet needs
- adv-20261019-214101-23ad62 | day=2nd of Jugust, 5500 | 2026-10-19T21:41:01.047919 | trigger=scheduled | severity=info | status=expired | auto_paused=False
  situation: Daily assessment for 2nd of Jugust, 5500
- adv-20261019-214132-7d5bc6 | day=2nd of Jugust, 5500 | 2026-10-19T21:41:32.781597 | trigger=reflex | severity=urgent | status=helped | auto_paused=True
  situation: Antigonos Baspho mood at 18% (major break risk)
  cause (recorded after the run): quest target at 18% on arrival; not enough time to fix four unmet needs
- adv-20261019-214235-bd2a99 | day=2nd of Jugust, 5500 | 2026-10-19T21:42:35.809305 | trigger=reflex | severity=urgent | status=helped | auto_paused=True
  situation: Antigonos Baspho mood at 14% (major break risk)
  cause (recorded after the run): quest target mood fell 18% -> 14% while needs were being fixed
- adv-20261019-215156-6df72e | day=3rd of Jugust, 5500 | 2026-10-19T21:51:56.099061 | trigger=scheduled | severity=info | status=helped | auto_paused=False
  situation: Daily assessment for 3rd of Jugust, 5500

## 8. Task

Produce Section A (JSON array) and Section B (markdown summary) as described in the instructions.
